const mongoose = require("mongoose");
const enums = require("../../../json/enums.json");
let validateEmail = function (email) {
  const re = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
  return re.test(email);
};

module.exports = (connection) => {
  const userSchema = new mongoose.Schema({
    firstName: String,
    lastName: String,
    userId: Number,
    officialEmail: {
      type: String,
      trim: true,
      lowercase: true,
      unique: true,
      required: false,
      validate: [validateEmail, "Please fill a valid email address"],
      match: [
        /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
        "Please fill a valid email address",
      ],
    },
    department: String,
    workType: String,
    designation: String,
    joiningDate: String,
    reportingTo: String,
    email: {
      type: String,
      trim: true,
      lowercase: true,
      unique: true,
      required: "Email address is required",
      validate: [validateEmail, "Please fill a valid email address"],
      match: [
        /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
        "Please fill a valid email address",
      ],
    },
    emailSecondary: {
      type: String,
      trim: true,
      lowercase: true,
      unique: true,
      //required: "Email address is required",
      validate: [validateEmail, "Please fill a valid secondary email address"],
      match: [
        /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
        "Please fill a valid email address",
      ],
    },
    password: {
      type: String,
      require: "Password is required",
    },
    passwordAttemp: { type: Number, default: 0 },
    isBlock: { type: Boolean, default: false },
    dob: String,
    address: {
      address1: {
        type: String,
      },
      address2: {
        type: String,
      },
      city: {
        type: String,
      },
      state: {
        type: String,
      },
      country: {
        type: String,
      },
      zip: {
        type: String,
      },
    },
    nationality: String,
    countryCode: String,
    gender: String,
    lastLogin: Date,
    isLoggedIn: { type: Boolean, default: false },
    isActive: {
      type: Boolean,
      default: true,
    },
    role: { type: String, default: enums.USER_TYPE.USER },
    resetPasswordToken: String,
    resetPasswordExpire: Date,
    createdAt: Date,
    updatedAt: Date,
    inActiveAt: Date,
    inActiveBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    reActivate: Boolean,
    reActivateAt: Date,
    reActivateBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    remainingPaidLeaves: { type: Number, default: 12 },
    usedPaidLeaves: { type: Number, default: 0 },

    fatherName : { type : String , required : true },
    motherName : { type : String , required : true },
    pancardNo : { type : String , required : true },
    adharcardNo : { type : String , required : true },
    employeePhoto : { type : String , required : true },
    bloodGroup: { type : String , required : true },
    phone: { type : String , required : true },

    previousEmployeeDetails :  {
      prevEmploymentType : { type : String  },
      prevOfficeBranch : { type : String  },
      prevOfficeAddress : { type : String  },
      prevOfficeContactNo : { type : String  },
      prevOfficeEmailId : { type : String  },
        prevDesignation : { type : String } , 
        prevPFAccountNo : { type : String } ,
        prevUANNo : { type : String } ,
        prevESINo : { type : String  } ,
        leavingDate : { type : String  } , 
        prevAnnualSalary : { type : String  } , 
        // payslips : { type : String  } , 
        payslipMonth1: { type : String },
        payslipMonth2: { type : String },
        payslipMonth2: { type : String },
        resignationForm : { type : String  }
    },

    bankinformation: {
      bankAccountNo: String,
      bankName: String,
      bankBranch: String,
      ifscCode: String,
    },

    emergencyContact: {
      emergencyContactEmail: String,
      emergencyContactName1: String,
      emergencyContactRalationship1: String,
      emergencyContactPhon1: String,
      emergencyContactName2: String,
      emergencyContactRalationship2: String,
      emergencyContactPhon2: String,
    },
    
    assignedCountry: {type: String, required: true, default: "India"}
  });
  return connection.model("user", userSchema, "user");
};
