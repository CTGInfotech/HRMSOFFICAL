const mongoose = require("mongoose");

module.exports = (connection) => {
  const paymentToEmployeeSchema = new mongoose.Schema({
    userId: Number,
    // salaryType: String,
    salaryMonth: String,
    salaryYear: Number,
    // salaryAmount: Number,
    addedAt: Date,
    addedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    // allowance: Number,
    // expensesClaim: Number,
    // totalPayableSalary: Number,
    paySlip: String,
    payedToEmployeeId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  });
  return connection.model(
    "paymentToEmployee",
    paymentToEmployeeSchema,
    "paymentToEmployee"
  );
};
