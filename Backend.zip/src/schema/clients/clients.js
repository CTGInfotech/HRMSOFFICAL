const mongoose = require("mongoose");
const enums = require("../../../json/enums.json");

module.exports = (connection) => {
  const clientSchema = new mongoose.Schema({

      clientId : { type : String , required : true , unique : true},
      clientName : { type : String , required : true },
      createAt : Date,
      updateAt : Date
    
  });
  return connection.model("Client", clientSchema, "client");
};
