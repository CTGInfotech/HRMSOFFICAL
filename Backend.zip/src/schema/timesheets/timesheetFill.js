const mongoose = require("mongoose");
const enums = require("../../../json/enums.json");

let validateEmail = function (email) {
  const re = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
  return re.test(email);
};

module.exports = (connection) => {
  const userSchema = new mongoose.Schema({
    user : { type: mongoose.Schema.Types.ObjectId, ref: "user", required : true },
    month : { type : String , required : true },
    timesheet : [{
        date : { type : String , required : true},
        day : { type : String , required : true},
        work_hrs : { type : Number , default : 0},
        away_hrs : {type: Number , default : 0},
        description : String,
        projectId: {type: mongoose.Schema.Types.ObjectId, ref: "project"},
        clientId: { type: mongoose.Schema.Types.ObjectId, ref: "Client" },
        isHoliday: {type: Boolean, default: false},
        allProjects: [{
        projectCode :  { type : String , required : true  } ,
        projectName : { type : String , required : true } ,
        startDate :  { type : String , required : true } ,
        endDate :  { type : String , required : true } ,
        client  : { type: mongoose.Schema.Types.ObjectId, ref: "Client" },
        createAt : Date , 
        updateAt : Date
      }]
    }],
    createdAt : { type : Date , default : new Date()},
    role : { type : String , required : true },
    status : {type : String , default : "FILLED"},
    rejectionRemark: {type: String, default: ""},
   
  });
  return connection.model("timesheetfill", userSchema, "timesheetfill");
};
