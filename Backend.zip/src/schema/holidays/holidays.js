const mongoose = require("mongoose");

module.exports = (connection) => {
  const holidaysSchema = new mongoose.Schema({
    description: String,
    name: String,
    startDate: Date,
    endDate: Date,
    year: Number,
    createdAt: Date,
    country: {type: String},
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    updatedAt: Date,
    updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    calenderColor: String,
    isActive: {
      type: Boolean,
      default: true,
    },
  });
  return connection.model("holidays", holidaysSchema, "holidays");
};
