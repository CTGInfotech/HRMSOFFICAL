const mongoose = require("mongoose");
const enums = require("../../../json/enums.json");

module.exports = (connection) => {
  const leavesSchema = new mongoose.Schema({
    leavesType: {
      type: String,
      default: enums.LEAVE_TYPE.UNPAID,
    },
    description: String,
    duration: String,
    appliedAt: Date,
    appliedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    approvedAt: Date,
    approvedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    rejectedAt: Date,
    rejectedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    leaveStatus: {
      type: String,
      default: enums.LEAVE_STATUS.PENDING,
    },
    leaveDate: Array,
    updatedAt: Date,
    updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    cancelledAt: Date,
    cancelledBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  });
  return connection.model("leaves", leavesSchema, "leaves");
};
