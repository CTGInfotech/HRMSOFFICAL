const mongoose = require("mongoose");

module.exports = (connection) => {
  const eventsSchema = new mongoose.Schema({
    name: String,
    description: String,
    duration: String,
    startDate: Date,
    endDate: Date,
    isActive: Boolean,
    postDate: Date,
    location: String,
    isUpdated: {
      type: Boolean,
      default: false,
    },
    updatedAt: Date,
    updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: "user" },
    postBy: { type: mongoose.Schema.Types.ObjectId, ref: "user" },
    eventTime: String,
    calenderColor: String,
  });
  return connection.model("events", eventsSchema, "events");
};
