const mongoose = require("mongoose");
const enums = require("../../../json/enums.json");

let validateEmail = function (email) {
  const re = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
  return re.test(email);
};

module.exports = (connection) => {
  const userSchema = new mongoose.Schema({
    firstName: String,
    lastName: String,
    fatherName : String,
    motherName : String,
    email: {
      type: String,
      trim: true,
      lowercase: true,
      unique: true,
      required: "Email address is required",
      validate: [validateEmail, "Please fill a valid email address"],
      match: [
        /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
        "Please fill a valid email address",
      ],
    },
    dob: String,
    address: {
      address1: {
        type: String,
      },
      address2: {
        type: String,
      },
      city: {
        type: String,
      },
      state: {
        type: String,
      },
      country: {
        type: String,
      },
      zip: {
        type: String,
      },
    },
    nationality: { type : String , required : true },
    phone1: { type : String , required : true },
    phone2: String,
    countryCode: String,
    gender: { type : String , required : true },
    createdAt: { type : Date , required : true },
    pancardNo : { type : String , required : true },
    adharcardNo : { type : String , required : true },
    employeePhoto : { type : String , required : true },
    bloodGroup: { type : String , required : true },

    previousEmployeeDetails : {
      prevEmploymentType : { type : String  },
      prevOfficeBranch : { type : String  },
      prevOfficeAddress : { type : String  },
      prevOfficeContactNo : { type : String  },
      prevOfficeEmailId : { type : String  },
        prevDesignation : { type : String } , 
        prevPFAccountNo : { type : String } ,
        prevUANNo : { type : String } ,
        prevESINo : { type : String  } ,
        leavingDate : { type : String  } , 
        prevAnnualSalary : { type : String  } , 
        // payslips : { type : String  } , 
        payslipMonth1: { type : String },
        payslipMonth2: { type : String },
        payslipMonth2: { type : String },
        resignationForm : { type : String  }
    },

    bankinformation: {
      bankAccountNo: String,
      bankName: String,
      bankBranch: String,
      ifscCode: String,
    },

    emergencyContact: {
      emergencyContactEmail: String,
      emergencyContactName1: String,
      emergencyContactRalationship1: String,
      emergencyContactPhon1: String,
      emergencyContactName2: String,
      emergencyContactRalationship2: String,
      emergencyContactPhon2: String,
    },
  });
  return connection.model("onboarding", userSchema, "onboarding");
};
