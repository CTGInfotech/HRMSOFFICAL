const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");

const logger = require("../../logger");
const utils = require("../../utils");

// Get User by ID
module.exports = exports = {
  handler: async (req, res) => {
      

    const { clientId } = req.params

    if (!clientId) {
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.INVALID_PARAMETERS,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.BAD_REQUEST)
          .json(utils.createResponseObject(data4createResponseObject));
    }

    try {
     
        let criteria = { client : clientId}
        console.log(criteria)
        let findProject = await global.models.GLOBAL.PROJECT.find(criteria)

        if (!findProject) {
          let data4createResponseObject = {
            req: req,
            result: -1,
            message: messages.PROJECT_DOES_NOT_EXIST,
            payload: {},
            logPayload: false,
          };
          return res
            .status(enums.HTTP_CODES.NOT_FOUND)
            .json(utils.createResponseObject(data4createResponseObject));
        } else {
            findProject = JSON.parse(JSON.stringify(findProject));
          let data4createResponseObject = {
            req: req,
            result: 0,
            message: messages.PROJECT_FETCH_SUCCESS,
            payload: findProject,
            logPayload: false,
          };
          return res
            .status(enums.HTTP_CODES.OK)
            .json(utils.createResponseObject(data4createResponseObject));
        }
    } catch (error) {
      logger.error(
        `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
      );
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.GENERAL,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
        .json(utils.createResponseObject(data4createResponseObject));
    }
  },
};
