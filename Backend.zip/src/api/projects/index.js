const addProject = require("./add-project")
const getAllProject = require("./get-all-projects")
const updateProejctById = require("./update-project-by-id")
const deleteProjectById = require("./delete-project-by-id")
const getAllProjectByClientId = require("./get-all-project-by-clientid")
const getMyProjectByClientId = require("./get-my-project-by-clientid")

module.exports = exports = {
    addProject,
    getAllProject,
    updateProejctById,
    deleteProjectById,
    getAllProjectByClientId,
    getMyProjectByClientId
};
