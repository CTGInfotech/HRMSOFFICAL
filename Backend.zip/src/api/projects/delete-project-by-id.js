const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");
const logger = require("../../logger");
const utils = require("../../utils");

// Delete User with the specified userId in the request
module.exports = exports = {
  // route handler
  handler: async (req, res) => {
    let { user } = req;
    const { id } = req.params;

    if (!id) {
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.INVALID_PARAMETERS,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.BAD_REQUEST)
        .json(utils.createResponseObject(data4createResponseObject));
    }

    let criteria = {
        _id : id
    }

    if ( user.role !== enums.USER_TYPE.ADMIN && user.role !== enums.USER_TYPE.HR ) {
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.NOT_ALLOWED,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.METHOD_NOT_ALLOWED)
          .json(utils.createResponseObject(data4createResponseObject));
      }
    else
    {
        try {
            let findProject = await global.models.GLOBAL.PROJECT.findOne(criteria);
      
            if (!findProject) {
              let data4createResponseObject = {
                req: req,
                result: -1,
                message: messages.PROJECT_DOES_NOT_EXIST,
                payload: {},
                logPayload: false,
              };
              return res
                .status(enums.HTTP_CODES.NOT_FOUND)
                .json(utils.createResponseObject(data4createResponseObject));
            } else {
              let deleteProject = await global.models.GLOBAL.PROJECT.findByIdAndRemove(criteria);
              if (!deleteProject) {
                let data4createResponseObject = {
                  req: req,
                  result: -1,
                  message: messages.PROJECT_DELETE_FAILED,
                  payload: {},
                  logPayload: false,
                };
                return res
                  .status(enums.HTTP_CODES.BAD_REQUEST)
                  .json(utils.createResponseObject(data4createResponseObject));
              } else {
                let data4createResponseObject = {
                  req: req,
                  result: 0,
                  message: messages.PROJECT_DELETE_SUCCESS,
                  payload: {},
                  logPayload: false,
                };
                return res
                  .status(enums.HTTP_CODES.OK)
                  .json(utils.createResponseObject(data4createResponseObject));
              }
            }
          } catch (error) {
            logger.error(
              `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
            );
            let data4createResponseObject = {
              req: req,
              result: -1,
              message: messages.GENERAL,
              payload: {},
              logPayload: false,
            };
            res
              .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
              .json(utils.createResponseObject(data4createResponseObject));
          }
    }



  },
};
