const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");

const logger = require("../../logger");
const utils = require("../../utils");

// User Profile update
module.exports = exports = {
  // route handler
  handler: async (req, res) => {
    const { user } = req;
    const { id } = req.params;
    try {
      if (
        user.role !== enums.USER_TYPE.ADMIN &&
        user.role !== enums.USER_TYPE.HR
      ) {
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.METHOD_NOT_ALLOWED,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.METHOD_NOT_ALLOWED)
          .json(utils.createResponseObject(data4createResponseObject));
      }
      let findLeave = await global.models.GLOBAL.LEAVES.findOne({
        _id: id,
      });
      if (!findLeave) {
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.LEAVE_NOT_FOUND,
          payload: {},
          logPayload: false,
        };
        res
          .status(enums.HTTP_CODES.NOT_FOUND)
          .json(utils.createResponseObject(data4createResponseObject));
      } else {
        if (findLeave.leaveStatus !== enums.LEAVE_STATUS.PENDING) {
          let data4createResponseObject = {
            req: req,
            result: -1,
            message: messages.LEAVE_STATUS_CHANGE_FAILED,
            payload: {},
            logPayload: false,
          };
          res
            .status(enums.HTTP_CODES.FORBIDDEN)
            .json(utils.createResponseObject(data4createResponseObject));
        } else {
          let leaveReject = await global.models.GLOBAL.LEAVES.findByIdAndUpdate(
            { _id: findLeave._id },
            {
              $set: {
                leaveStatus: enums.LEAVE_STATUS.REJECTED,
                rejectedBy: user._id,
                rejectedAt: new Date(),
              },
            },
            { new: true }
          );
          if (!leaveReject) {
            let data4createResponseObject = {
              req: req,
              result: -1,
              message: messages.LEAVE_REJECT_FAILED,
              payload: {},
              logPayload: false,
            };
            return res
              .status(enums.HTTP_CODES.BAD_REQUEST)
              .json(utils.createResponseObject(data4createResponseObject));
          } else {
            if(findLeave.leavesType === enums.LEAVE_TYPE.PAID){
              
              const intDuration = parseInt(findLeave.duration);
              await global.models.GLOBAL.USER.findOneAndUpdate(
                { _id: findLeave.appliedBy },
                { $inc: { remainingPaidLeaves: intDuration, usedPaidLeaves: -intDuration } },
                { new: true }
              );
              }
            let data4createResponseObject = {
              req: req,
              result: 0,
              message: messages.LEAVE_REJECTED,
              payload: { leaveReject },
              logPayload: false,
            };
            return res
              .status(enums.HTTP_CODES.OK)
              .json(utils.createResponseObject(data4createResponseObject));
          }
        }
      }
    } catch (error) {
      logger.error(
        `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
      );
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.GENERAL,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
        .json(utils.createResponseObject(data4createResponseObject));
    }
  },
};
