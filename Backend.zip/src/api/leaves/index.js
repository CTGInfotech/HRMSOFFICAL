const addLeave = require("./add-leave-request");
const getLeaveByUser = require("./get-all-leaves-by-user");
const updateLeave = require("./update-leave-request");
const acceptLeave = require("./accept-leave-request");
const rejectLeave = require("./reject-leave-request");

module.exports = {
  addLeave,
  getLeaveByUser,
  updateLeave,
  acceptLeave,
  rejectLeave,
};
