const Joi = require("joi");
const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");
const logger = require("../../logger");
const utils = require("../../utils");

// Holiday Create
module.exports = exports = {
  // route validation
  validation: Joi.object({
    leavesType: Joi.string().required(),
    description: Joi.string().required(),
    duration: Joi.string().required(),
    leaveDate: Joi.array().items(Joi.date()).required(),
  }),

  // route handler
  handler: async (req, res) => {
    const { user } = req;
    const { id } = req.query;
    const { leavesType, description, duration, leaveDate } = req.body;
    console.log(req.body.leaveDate);

   

    if (!leavesType || !description || !duration || !leaveDate) {
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.INVALID_PARAMETERS,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.BAD_REQUEST)
        .json(utils.createResponseObject(data4createResponseObject));
    }

    try {
      let leaveData = {
        leavesType: leavesType,
        description: description,
        appliedAt: new Date(),
        appliedBy: id ? id : user._id,
        leaveStatus: enums.LEAVE_STATUS.PENDING,
        duration: duration,
        leaveDate: leaveDate,
      };

      
      const getLeavesCount = await global.models.GLOBAL.USER.findOne({
        _id: id ? id : user._id,
      }).select("id remainingPaidLeaves usedPaidLeaves");
      const intDuration = parseInt(duration);
      if(leavesType === enums.LEAVE_TYPE.PAID){
        if(getLeavesCount.remainingPaidLeaves < duration){
          let data4createResponseObject = {
            req: req,
            result: -1,
            message: messages.LEAVE_PAID_FAILED,
            payload: {},
            logPayload: false,
          };
          return res
            .status(enums.HTTP_CODES.BAD_REQUEST)
            .json(utils.createResponseObject(data4createResponseObject));
        }
      }
      const newLeave = await global.models.GLOBAL.LEAVES.create(leaveData);
      if(leavesType === enums.LEAVE_TYPE.PAID){
      await global.models.GLOBAL.USER.findOneAndUpdate(
        { _id: id ? id : user._id },
        { $inc: { remainingPaidLeaves: -intDuration, usedPaidLeaves: intDuration } },
        { new: true }
      );
      }

      if (!newLeave) {
        let data4createResponseObject = {
          req: req,
          result: 0,
          message: messages.LEAVE_CREATED_FAILED,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.BAD_REQUEST)
          .json(utils.createResponseObject(data4createResponseObject));
      } else {
        let data4createResponseObject = {
          req: req,
          result: 1,
          message: messages.LEAVE_CREATED,
          payload: newLeave,
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.OK)
          .json(utils.createResponseObject(data4createResponseObject));
      }
    } catch (error) {
      logger.error(
        `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
      );
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.GENERAL,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
        .json(utils.createResponseObject(data4createResponseObject));
    }
  },
};
