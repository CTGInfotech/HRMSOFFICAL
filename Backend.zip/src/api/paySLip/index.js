const addPaySlip = require("./add-paySlip");
const getPaySlip = require("./get-paySlip");
const deletePaySlip = require("./delete-paySlip");

module.exports = exports = {
  addPaySlip,
  getPaySlip,
  deletePaySlip,
};
