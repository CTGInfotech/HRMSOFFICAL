const Joi = require("joi");
const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");
const logger = require("../../logger");
const utils = require("../../utils");

// Pay=-Slip Addition
module.exports = exports = {
  // route handler
  handler: async (req, res) => {
    const { user } = req;
    const { id } = req.params;
    const {
      userId,
      // salaryAmount,
      // salaryType,
      salaryMonth,
      salaryYear,
      // allowance,
      // expensesClaim,
    } = req.body;
    if (
      !id ||
      !userId ||
      // !salaryType ||
      !salaryMonth ||
      !salaryYear 
      // !salaryAmount ||
      // !allowance ||
      // !expensesClaim
    ) {
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.INVALID_PARAMETERS,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.BAD_REQUEST)
        .json(utils.createResponseObject(data4createResponseObject));
    }

    try {
      let findUser = await global.models.GLOBAL.USER.findOne({ userId: userId });
      if (!findUser) {
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.USER_NOT_FOUND,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.BAD_REQUEST)
          .json(utils.createResponseObject(data4createResponseObject));
      } else {
        if (req.paySlip) {
          req.body.paySlip = req.paySlip[0];
        }

        // const totalSalary =
        //   parseInt(salaryAmount) +
        //   parseInt(allowance) +
        //   parseInt(expensesClaim);
        let salaryData = {
          userId: userId,
          // salaryType: salaryType,
          salaryMonth: salaryMonth,
          salaryYear: salaryYear,
          // salaryAmount: salaryAmount,
          // allowance: allowance,
          // expensesClaim: expensesClaim,
          payedToEmployeeId: findUser._id,
          // totalPayableSalary: totalSalary,
          paySlip: req.body.paySlip,
          addedBy: user._id,
          addedAt: new Date(),
        };
        if (
          user.role !== enums.USER_TYPE.ADMIN &&
          user.role !== enums.USER_TYPE.HR
        ) {
          let data4createResponseObject = {
            req: req,
            result: -1,
            message: messages.NOT_ALLOWED,
            payload: {},
            logPayload: false,
          };
          return res
            .status(enums.HTTP_CODES.METHOD_NOT_ALLOWED)
            .json(utils.createResponseObject(data4createResponseObject));
        }

        const newSalary = await global.models.GLOBAL.PAYMENT_TO_EMPLOYEE.create(
          salaryData
        );
        if (!newSalary) {
          let data4createResponseObject = {
            req: req,
            result: 0,
            message: messages.PAYSLIP_ADD_FAILED,
            payload: {},
            logPayload: false,
          };
          return res
            .status(enums.HTTP_CODES.BAD_REQUEST)
            .json(utils.createResponseObject(data4createResponseObject));
        } else {
          let data4createResponseObject = {
            req: req,
            result: 1,
            message: messages.PAYSLIP_ADDED,
            payload: newSalary,
            logPayload: false,
          };
          return res
            .status(enums.HTTP_CODES.OK)
            .json(utils.createResponseObject(data4createResponseObject));
        }
      }
    } catch (error) {
      logger.error(
        `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
      );
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.GENERAL,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
        .json(utils.createResponseObject(data4createResponseObject));
    }
  },
  bulkHandler: async (req, res) => {
    const { user } = req;
    const {
      userId,
      // salaryAmount,
      // salaryType,
      salaryMonth,
      salaryYear,
      // allowance,
      // expensesClaim,
    } = req.body;
    if (
      !userId ||
      // !salaryType ||
      !salaryMonth ||
      !salaryYear 
      // !salaryAmount ||
      // !allowance ||
      // !expensesClaim
    ) {
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.INVALID_PARAMETERS,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.BAD_REQUEST)
        .json(utils.createResponseObject(data4createResponseObject));
    }

    try {
      let findUser = await global.models.GLOBAL.USER.findOne({ userId: userId });
      if (!findUser) {
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.USER_NOT_FOUND,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.BAD_REQUEST)
          .json(utils.createResponseObject(data4createResponseObject));
      } else {
        if (req.paySlip) {
          req.body.paySlip = req.paySlip[0];
        }

        // const totalSalary =
        //   parseInt(salaryAmount) +
        //   parseInt(allowance) +
        //   parseInt(expensesClaim);
        let salaryData = {
          userId: userId,
          // salaryType: salaryType,
          salaryMonth: salaryMonth,
          salaryYear: salaryYear,
          // salaryAmount: salaryAmount,
          // allowance: allowance,
          // expensesClaim: expensesClaim,
          payedToEmployeeId: findUser._id,
          // totalPayableSalary: totalSalary,
          paySlip: req.body.paySlip,
          addedBy: user._id,
          addedAt: new Date(),
        };
        if (
          user.role !== enums.USER_TYPE.ADMIN &&
          user.role !== enums.USER_TYPE.HR
        ) {
          let data4createResponseObject = {
            req: req,
            result: -1,
            message: messages.NOT_ALLOWED,
            payload: {},
            logPayload: false,
          };
          return res
            .status(enums.HTTP_CODES.METHOD_NOT_ALLOWED)
            .json(utils.createResponseObject(data4createResponseObject));
        }

        const newSalary = await global.models.GLOBAL.PAYMENT_TO_EMPLOYEE.create(
          salaryData
        );
        if (!newSalary) {
          let data4createResponseObject = {
            req: req,
            result: 0,
            message: messages.PAYSLIP_ADD_FAILED,
            payload: {},
            logPayload: false,
          };
          return res
            .status(enums.HTTP_CODES.BAD_REQUEST)
            .json(utils.createResponseObject(data4createResponseObject));
        } else {
          let data4createResponseObject = {
            req: req,
            result: 1,
            message: messages.PAYSLIP_ADDED,
            payload: newSalary,
            logPayload: false,
          };
          return res
            .status(enums.HTTP_CODES.OK)
            .json(utils.createResponseObject(data4createResponseObject));
        }
      }
    } catch (error) {
      logger.error(
        `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
      );
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.GENERAL,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
        .json(utils.createResponseObject(data4createResponseObject));
    }
  },
};
