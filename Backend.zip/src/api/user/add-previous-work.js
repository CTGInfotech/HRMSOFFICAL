const Joi = require("joi");
const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");
const logger = require("../../logger");
const utils = require("../../utils");

// User Registration
module.exports = exports = {
  // route validation
  validation: Joi.object({
    employmentType: Joi.string().required(),
    branch: Joi.string().required(),
    address: Joi.string().required(),
    contactNumber: Joi.number().required(),
    email: Joi.string().required(),
    designation: Joi.string().required(),
    pfAccount: Joi.string().required(),
    uanNo: Joi.number().required(),
    esiNo: Joi.number().required(),
    leavingDate: Joi.string().required(),
    annualSalary: Joi.string().required(),
  }),

  // route handler
  handler: async (req, res) => {
    const { user } = req;
    const {
      employmentType,
      branch,
      address,
      contactNumber,
      email,
      designation,
      pfAccount,
      uanNo,
      esiNo,
      leavingDate,
      annualSalary,
    } = req.body;

    if (
      !employmentType ||
      !branch ||
      !address ||
      !contactNumber ||
      !email ||
      !designation ||
      !pfAccount ||
      !uanNo ||
      !esiNo ||
      !leavingDate ||
      !annualSalary
    ) {
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.INVALID_PARAMETERS,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.BAD_REQUEST)
        .json(utils.createResponseObject(data4createResponseObject));
    }

    try {
      let previousWorkInformation = {
        userId: user._id,
        employmentType: employmentType,
        branch: branch,
        address: address,
        contactNumber: contactNumber,
        email: email,
        designation: designation,
        pfAccount: pfAccount,
        uanNo: uanNo,
        esiNo: esiNo,
        leavingDate: leavingDate,
        annualSalary: annualSalary,
      };

      const newInformation =
        await global.models.GLOBAL.PREVIOUS_WORK_INFO.create(
          previousWorkInformation
        );
      if (!newInformation) {
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: "Error in creating previous work information",
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.BAD_REQUEST)
          .json(utils.createResponseObject(data4createResponseObject));
      } else {
        let data4createResponseObject = {
          req: req,
          result: 1,
          message: messages.WORK_INFO_ADDED,
          payload: { newInformation },
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.OK)
          .json(utils.createResponseObject(data4createResponseObject));
      }
    } catch (error) {
      logger.error(
        `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
      );
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.GENERAL,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
        .json(utils.createResponseObject(data4createResponseObject));
    }
  },
};
