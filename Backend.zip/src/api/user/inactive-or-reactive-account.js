const Joi = require("joi");

const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");

const logger = require("../../logger");
const utils = require("../../utils");

// User Profile update
module.exports = exports = {
  // route handler
  handler: async (req, res) => {
    const { user } = req;
    const { id } = req.params;
    try {
      let findUser = await global.models.GLOBAL.USER.findOne({
        _id: id,
      });
      if (!findUser) {
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.USER_DOES_NOT_EXIST,
          payload: {},
          logPayload: false,
        };
        res
          .status(enums.HTTP_CODES.NOT_FOUND)
          .json(utils.createResponseObject(data4createResponseObject));
      } else {
        if (findUser.isActive === true) {
          let updateStatus = await global.models.GLOBAL.USER.findByIdAndUpdate(
            { _id: findUser._id },
            {
              $set: {
                isActive: false,
                inActiveAt: new Date(),
                inActiveBy: user._id,
              },
            },
            { new: true }
          );
          if (!updateStatus) {
            let data4createResponseObject = {
              req: req,
              result: -1,
              message: messages.USER_INACTIVATE_FAILED,
              payload: {},
              logPayload: false,
            };
            return res
              .status(enums.HTTP_CODES.BAD_REQUEST)
              .json(utils.createResponseObject(data4createResponseObject));
          } else {
            let data4createResponseObject = {
              req: req,
              result: 0,
              message: messages.USER_INACTIVATE_SUCCESS,
              payload: {},
              logPayload: false,
            };
            return res
              .status(enums.HTTP_CODES.OK)
              .json(utils.createResponseObject(data4createResponseObject));
          }
        } else {
          let updateStatus = await global.models.GLOBAL.USER.findByIdAndUpdate(
            { _id: findUser._id },
            {
              $set: {
                isActive: true,
                reActivate: true,
                reActiveAt: new Date(),
                inActiveBy: user._id,
              },
            },
            { new: true }
          );
          if (!updateStatus) {
            let data4createResponseObject = {
              req: req,
              result: -1,
              message: messages.USER_REACTIVATE_FAILED,
              payload: {},
              logPayload: false,
            };
            return res
              .status(enums.HTTP_CODES.BAD_REQUEST)
              .json(utils.createResponseObject(data4createResponseObject));
          } else {
            let data4createResponseObject = {
              req: req,
              result: 0,
              message: messages.USER_REACTIVATE_SUCCESS,
              payload: {},
              logPayload: false,
            };
            return res
              .status(enums.HTTP_CODES.OK)
              .json(utils.createResponseObject(data4createResponseObject));
          }
        }
      }
    } catch (error) {
      logger.error(
        `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
      );
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.GENERAL,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
        .json(utils.createResponseObject(data4createResponseObject));
    }
  },
};
