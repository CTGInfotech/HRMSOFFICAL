const userRegistration = require("./registration");
const userLogin = require("./login");
const userUpdate = require("./update-user");
const deleteUser = require("./delete-user");
const resetPassword = require("./reset-password");
const getEmployee = require("./get-all-employee");
const updateStatus = require("./inactive-or-reactive-account");
const forgotPassword = require("./forgot-password-link");
const changePassword = require("./change-password");
const userLogout = require("./logout");
const getAdmin = require("./get-all-admin");
const getHr = require("./get-all-hr");
const getCount = require("./get-user-count");
const upCommingBirthday = require("./upComming-birthday");
const searchUser = require("./search-user");
const previousWorkInfo = require("./add-previous-work");
const addEmployee = require("./add-employee")
const getHolidays=require('./get-holidays-assignedCountry')

module.exports = exports = {
  userRegistration,
  userLogin,
  userUpdate,
  deleteUser,
  resetPassword,
  getEmployee,
  updateStatus,
  forgotPassword,
  changePassword,
  userLogout,
  getAdmin,
  getHr,
  getCount,
  upCommingBirthday,
  searchUser,
  previousWorkInfo,
  addEmployee,
  getHolidays
};
