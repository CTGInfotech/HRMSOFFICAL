const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");

const logger = require("../../logger");
const utils = require("../../utils");

// Get User by ID
module.exports = exports = {
  handler: async (req, res) => {
    const { user } = req;
    try {
      let { id  , search} = req.query;
      let criteria;
      if (id) {
        criteria = {
          _id: id,
        };
      }

      if (search) {
        criteria = {
          ...criteria,
          $or: [
            {
              firstName: {
                $regex: search,
                $options: "i",
              },
            },
            {
              email: {
                $regex: search,
                $options: "i",
              },
            },
          ],
        };
      }

      let page = req.query.page ? parseInt(req.query.page) : 1;
      let limit = req.query.limit ? parseInt(req.query.limit) : 10;
      let skip = (page - 1) * limit;
      if (
        user.role !== enums.USER_TYPE.ADMIN &&
        user.role !== enums.USER_TYPE.HR
      ) {
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.NOT_ALLOWED,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.METHOD_NOT_ALLOWED)
          .json(utils.createResponseObject(data4createResponseObject));
      } else {
        let findUser = await global.models.GLOBAL.USER.find({
          $and: [
            { ...criteria },
            {
              _id: { $nin: [user._id] },
              role: { $eq: enums.USER_TYPE.USER },
            },
          ],
        })
          .select("-password -__v -updatedAt")
          .skip(skip)
          .limit(limit)
          .sort({
            userId: -1,
          });

        let total = await global.models.GLOBAL.USER.countDocuments({
          $and: [
            { ...criteria },
            {
              _id: { $nin: [user._id] },
              role: { $eq: enums.USER_TYPE.USER },
            },
          ],
        });

        if (!findUser) {
          let data4createResponseObject = {
            req: req,
            result: -1,
            message: messages.USER_DOES_NOT_EXIST,
            payload: {},
            logPayload: false,
          };
          return res
            .status(enums.HTTP_CODES.NOT_FOUND)
            .json(utils.createResponseObject(data4createResponseObject));
        } else {
          findUser = JSON.parse(JSON.stringify(findUser));
          let data4createResponseObject = {
            req: req,
            result: 0,
            message: messages.USER_FETCH_SUCCESS,
            payload: { findUser, page: page, limit: limit, count: total },
            logPayload: false,
          };
          return res
            .status(enums.HTTP_CODES.OK)
            .json(utils.createResponseObject(data4createResponseObject));
        }
      }
    } catch (error) {
      logger.error(
        `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
      );
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.GENERAL,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
        .json(utils.createResponseObject(data4createResponseObject));
    }
  },
};
