const Joi = require("joi");
const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");
const logger = require("../../logger");
const utils = require("../../utils");

// User Registration
module.exports = exports = {
  // route validation
  validation: Joi.object({
    userId: Joi.number().required(),
    // officialEmail: Joi.string().required(),
    // department: Joi.string().required(),
    // workType: Joi.string().required(),
    // designation: Joi.string().required(),
    // joiningDate: Joi.string().required(),
    // reportingTo: Joi.string().required(),
    firstName: Joi.string().required(),
    lastName: Joi.string().required(),
    email: Joi.string().required(),
    password: Joi.string().required(),
    dob: Joi.date().allow(""),
    nationality: Joi.string().allow(""),
    address: Joi.string().allow(""),
    gender: Joi.string().allow(""),
    // countryCode: Joi.string().required(),
    // fatherName: Joi.string().allow(""),
    // motherName: Joi.string().allow(""),
    // bloodGroup: Joi.string().allow(""),
  }),

  // route handler
  handler: async (req, res) => {
    const {
      userId,
      // officialEmail,
      // department,
      // workType,
      // designation,
      // joiningDate,
      // reportingTo,
      firstName,
      lastName,
      email,
      password,
      dob,
      nationality,
      phone,
      address,
      gender,
      // countryCode,
      // bloodGroup,
      // motherName,
      // fatherName,
    } = req.body;
    const role = req.body.role ? req.body.role : "employee";

    if (
      !userId ||
      !firstName ||
      !lastName ||
      // !officialEmail ||
      // !department ||
      // !workType ||
      // !designation ||
      // !joiningDate ||
      // !reportingTo ||
      !email ||
      !password ||
      !dob ||
      !nationality ||
      !phone ||
      !address ||
      !gender
      // !countryCode
    ) {
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.INVALID_PARAMETERS,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.BAD_REQUEST)
        .json(utils.createResponseObject(data4createResponseObject));
    }

    try {
      let findUser = await global.models.GLOBAL.USER.find({
        $or: [{ email: email }, { phone: phone }, { userId: userId }],
      });
      if (findUser.length > 0) {
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.USER_ALREADY_EXISTS,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.DUPLICATE_VALUE)
          .json(utils.createResponseObject(data4createResponseObject));
      } else {
        let userRegistrationDate = {
          userId: userId,
          firstName: firstName,
          lastName: lastName,
          email: email,
          // officialEmail: officialEmail,
          // department: department,
          // workType: workType,
          // designation: designation,
          // joiningDate: joiningDate,
          // reportingTo: reportingTo,
          dob: dob,
          password: password,
          nationality: nationality,
          role: role,
          phone: phone,
          address: address,
          gender: gender,
          // countryCode: countryCode,
          createdAt: Date.now(),
          isLoggedIn: false,
          // fatherName: fatherName,
          // motherName: motherName,
          // bloodGroup: bloodGroup,
        };

        const newUser = await global.models.GLOBAL.USER.create(
          userRegistrationDate
        );
        if (!newUser) {
          let data4createResponseObject = {
            req: req,
            result: -1,
            message: messages.USER_REGISTRATION_FAILED,
            payload: {},
            logPayload: false,
          };
          return res
            .status(enums.HTTP_CODES.BAD_REQUEST)
            .json(utils.createResponseObject(data4createResponseObject));
        } else {
          let data4createResponseObject = {
            req: req,
            result: 0,
            message: messages.USER_REGISTRATION_SUCCESS,
            payload: newUser,
            logPayload: false,
          };
          return res
            .status(enums.HTTP_CODES.OK)
            .json(utils.createResponseObject(data4createResponseObject));
        }
      }
    } catch (error) {
      logger.error(
        `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
      );
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.GENERAL,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
        .json(utils.createResponseObject(data4createResponseObject));
    }
  },
};
