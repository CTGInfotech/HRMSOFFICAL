const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");

const logger = require("../../logger");
const utils = require("../../utils");

// Get User by ID
module.exports = exports = {
  handler: async (req, res) => {
    const { user } = req;
    try {
      if (user.role === enums.USER_TYPE.ADMIN) {
        let hrCount = await global.models.GLOBAL.USER.countDocuments({
          role: enums.USER_TYPE.HR,
        });
        let employeeCount = await global.models.GLOBAL.USER.countDocuments({
          role: enums.USER_TYPE.USER,
        });

        let data4createResponseObject = {
          req: req,
          result: 0,
          message: messages.SUCCESS,
          payload: {
            hrCount: hrCount,
            employeeCount: employeeCount,
          },
        };
        return res
          .status(enums.HTTP_CODES.OK)
          .json(utils.createResponseObject(data4createResponseObject));
      } else if (user.role === enums.USER_TYPE.HR) {
        let employeeCount = await global.models.GLOBAL.USER.countDocuments({
          role: enums.USER_TYPE.USER,
        });

        let data4createResponseObject = {
          req: req,
          result: 0,
          message: messages.SUCCESS,
          payload: { employeeCount: employeeCount },
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.OK)
          .json(utils.createResponseObject(data4createResponseObject));
      } else {
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.NOT_ALLOWED,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.METHOD_NOT_ALLOWED)
          .json(utils.createResponseObject(data4createResponseObject));
      }
    } catch (error) {
      logger.error(
        `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
      );
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.GENERAL,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
        .json(utils.createResponseObject(data4createResponseObject));
    }
  },
};
