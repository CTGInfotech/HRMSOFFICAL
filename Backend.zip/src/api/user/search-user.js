const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");

const logger = require("../../logger");
const utils = require("../../utils");

// Get User by ID
module.exports = exports = {
  handler: async (req, res) => {
    const { searchIn } = req.query;
    const { search } = req.query;
    try {
      let criteria = {};
      if (searchIn === "hr") {
        criteria = {
          role: { $eq: enums.USER_TYPE.HR },
        };
      } else if (searchIn === "employee") {
        criteria = {
          role: { $eq: enums.USER_TYPE.USER },
        };
      }
      if (search) {
        criteria = {
          ...criteria,
          $or: [
            {
              firstName: {
                $regex: search,
                $options: "i",
              },
            },
            {
              email: {
                $regex: search,
                $options: "i",
              },
            },
          ],
        };
      }
      let page = req.query.page ? parseInt(req.query.page) : 1;
      let limit = req.query.limit ? parseInt(req.query.limit) : 10;
      let skip = (page - 1) * limit;
      let findUser = await global.models.GLOBAL.USER.find(criteria)
        .sort({
          createdAt: -1,
        })
        .skip(skip)
        .limit(limit);
      let total = await global.models.GLOBAL.USER.countDocuments(criteria);
      let data4createResponseObject = {
        req: req,
        result: 1,
        message: messages.SUCCESS,
        payload: {
          users: findUser,
          total: total,
          page: page,
          limit: limit,
        },
      };
      return res
        .status(enums.HTTP_CODES.OK)
        .json(utils.createResponseObject(data4createResponseObject));
    } catch (error) {
      logger.error(
        `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
      );
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.GENERAL,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
        .json(utils.createResponseObject(data4createResponseObject));
    }
  },
};
