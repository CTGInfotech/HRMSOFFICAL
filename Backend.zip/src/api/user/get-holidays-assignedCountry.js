const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");

const logger = require("../../logger");
const utils = require("../../utils");

// Get User by ID
module.exports = exports = {
  handler: async (req, res) => {
    const { user } = req;
    try 
    {
        let {month} = req.params;
        let country = user?.assignedCountry;
        month=parseInt(month);
        if(!country) country="India";

        console.log(country);
        let findHolidays = await global.models.GLOBAL.HOLIDAYS.find({
          country
        })

         console.log(findHolidays)
        if (!findHolidays) {
            let data4createResponseObject = {
              req: req,
              result: -1,
              message: messages.HOLIDAY_NOT_FOUND,
              payload: {},
              logPayload: false,
            };
            return res
              .status(enums.HTTP_CODES.NOT_FOUND)
              .json(utils.createResponseObject(data4createResponseObject));
        }else{
             findHolidays = JSON.parse(JSON.stringify(findHolidays));
            let data4createResponseObject;
             if(month>=0 && month<12)
             {


             let filteredFindHolidays=findHolidays.filter((holiday)=>{
                    let startMonth= new Date(holiday.startDate).getMonth();
                    let endMonth= new Date(holiday.endDate).getMonth();
                    return (month==startMonth || month==endMonth);       
             })
             console.log(filteredFindHolidays);

               data4createResponseObject = {
                  req: req,
                  result: 0,
                  message: messages.USER_FETCH_SUCCESS,
                  payload: { holidaysData: filteredFindHolidays},
                  logPayload: false,
                };
             }else{

              data4createResponseObject = {
                  req: req,
                  result: 0,
                  message: messages.USER_FETCH_SUCCESS,
                  payload: { holidaysData: findHolidays},
                  logPayload: false,
                };
              }

              return res
                .status(enums.HTTP_CODES.OK)
                .json(utils.createResponseObject(data4createResponseObject));
        }
    } catch (error) {
      logger.error(
        `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
      );
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.GENERAL,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
        .json(utils.createResponseObject(data4createResponseObject));
    }
  },
};
