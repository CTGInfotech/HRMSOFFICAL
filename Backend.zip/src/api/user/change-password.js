const Joi = require("joi");

const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");

const logger = require("../../logger");
const utils = require("../../utils");
const nodemailer = require("nodemailer");

// User Profile update
module.exports = exports = {
  validation: Joi.object({
    password: Joi.string().required(),
    email: Joi.string().required(),
  }),
  handler: async (req, res) => {
    const { token } = req.params;
    const { email, password } = req.body;

    if (!token || !password || !email) {
      const data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.INVALID_PARAMETERS,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.BAD_REQUEST)
        .json(utils.createResponseObject(data4createResponseObject));
    }
    try {
      let findUser = await global.models.GLOBAL.USER.findOne({
        email: email,
      });
      if (findUser.isLoggedIn === true) {
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.ALREADY_LOGGED_IN,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.BAD_REQUEST)
          .json(utils.createResponseObject(data4createResponseObject));
      } else if (findUser.resetPasswordToken.toString() !== token.toString()) {
        const data4createResponseObject = {
          req: req,
          result: 0,
          message: messages.INVALID_LINK,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.BAD_REQUEST)
          .json(utils.createResponseObject(data4createResponseObject));
      } else if (findUser.resetPasswordExpire < Date.now()) {
        const data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.INVALID_LINK,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.BAD_REQUEST)
          .json(utils.createResponseObject(data4createResponseObject));
      } else {
        await global.models.GLOBAL.USER.findByIdAndUpdate(
          findUser._id,
          {
            $set: {
              password: password,
              resetPasswordToken: null,
              resetPasswordExpire: null,
            },
          },
          { new: true }
        );
        console.log("MAIL SENDING");
        let transporter = nodemailer.createTransport({
          // service: "gmail",
          host: process.env.SMTP_HOST,
          port: process.env.SMTP_PORT,
          secure: false,
          auth: {
            user: process.env.SMTP_USERNAME,
            pass: process.env.SMTP_PASSWORD,
          },
        });
        let info = await transporter.sendMail({
          from: process.env.SMTP_FROM_EMAIL,
          to: findUser.email,
          subject: "CTG HRMS | Your password has been changed",
          text:
            "Hello" +
            " " +
            findUser.firstName +
            ",\n\n" +
            " - This is a confirmation that the password for your account " +
            findUser.email +
            " has just been changed.\n",
        });
        console.log("Message sent: %s", info.messageId);

        const data4createResponseObject = {
          req: req,
          result: 0,
          message: messages.PASSWORD_UPDATED,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.OK)
          .json(utils.createResponseObject(data4createResponseObject));
      }
    } catch (error) {
      logger.error(
        `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
      );
      const data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.GENERAL,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
        .json(utils.createResponseObject(data4createResponseObject));
    }
  },
};
