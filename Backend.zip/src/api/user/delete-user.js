const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");
const logger = require("../../logger");
const utils = require("../../utils");

// Delete User with the specified userId in the request
module.exports = exports = {
  // route handler
  handler: async (req, res) => {
    let { user } = req;
    const { userId } = req.params;

    if (!userId) {
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.INVALID_PARAMETERS,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.BAD_REQUEST)
        .json(utils.createResponseObject(data4createResponseObject));
    }
    try {
      let findUser = await global.models.GLOBAL.USER.findOne({
        _id: userId,
      });

      if (!findUser) {
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.USER_DOES_NOT_EXIST,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.NOT_FOUND)
          .json(utils.createResponseObject(data4createResponseObject));
      } else {
        let deleteUser = await global.models.GLOBAL.USER.findByIdAndRemove({
          _id: userId,
        });
        await global.models.GLOBAL.LEAVES.deleteMany({
          appliedBy: userId,
        });
        await global.models.GLOBAL.PAYMENT_TO_EMPLOYEE.deleteMany({
          payedToEmployeeId: userId,
        });
        await global.models.GLOBAL.TIMESHEET_FILL.deleteMany({
          user: userId,
        });
        if (!deleteUser) {
          let data4createResponseObject = {
            req: req,
            result: -1,
            message: messages.USER_DELETE_FAILED,
            payload: {},
            logPayload: false,
          };
          return res
            .status(enums.HTTP_CODES.BAD_REQUEST)
            .json(utils.createResponseObject(data4createResponseObject));
        } else {
          let data4createResponseObject = {
            req: req,
            result: 0,
            message: messages.USER_DELETE_SUCCESS,
            payload: {},
            logPayload: false,
          };
          return res
            .status(enums.HTTP_CODES.OK)
            .json(utils.createResponseObject(data4createResponseObject));
        }
      }
    } catch (error) {
      logger.error(
        `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
      );
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.GENERAL,
        payload: {},
        logPayload: false,
      };
      res
        .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
        .json(utils.createResponseObject(data4createResponseObject));
    }
  },
};
