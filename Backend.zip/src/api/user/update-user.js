const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");

const logger = require("../../logger");
const utils = require("../../utils");

// User Profile update
module.exports = exports = {
  // route handler
  handler: async (req, res) => {
    const { user } = req;
    const { id } = req.query;

    if (!id) {
      try {
        let findUser1 = await global.models.GLOBAL.USER.findOne({
          _id: user._id,
        });
        if (!findUser1) {
          let data4createResponseObject = {
            req: req,
            result: -1,
            message: messages.USER_DOES_NOT_EXIST,
            payload: {},
            logPayload: false,
          };
          return res
            .status(enums.HTTP_CODES.NOT_FOUND)
            .json(utils.createResponseObject(data4createResponseObject));
        } else {
          let findUser = req.body

          Object.assign(findUser1, findUser);          


          let updateUser = await global.models.GLOBAL.USER.findByIdAndUpdate(
            findUser1._id,
            findUser1
          );
          if (!updateUser) {
            let data4createResponseObject = {
              req: req,
              result: -1,
              message: messages.USER_UPDATE_FAILED,
              payload: {},
              logPayload: false,
            };
            return res
              .status(enums.HTTP_CODES.BAD_REQUEST)
              .json(utils.createResponseObject(data4createResponseObject));
          } else {
            updateUser = await global.models.GLOBAL.USER.findOne({
              _id: user._id,
            }).select("-password -__v -updatedAt");
            let data4createResponseObject = {
              req: req,
              result: 0,
              message: messages.USER_UPDATED,
              payload: { updateUser: updateUser },
              logPayload: false,
            };
            return res
              .status(enums.HTTP_CODES.OK)
              .json(utils.createResponseObject(data4createResponseObject));
          }
        }
      } catch (error) {
        logger.error(
          `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
        );
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.GENERAL,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
          .json(utils.createResponseObject(data4createResponseObject));
      }
    } else {
      try {
        let findUser1 = await global.models.GLOBAL.USER.findOne({
          _id: id,
        });
        if (!findUser1) {
          let data4createResponseObject = {
            req: req,
            result: -1,
            message: messages.USER_DOES_NOT_EXIST,
            payload: {},
            logPayload: false,
          };
          return res
            .status(enums.HTTP_CODES.NOT_FOUND)
            .json(utils.createResponseObject(data4createResponseObject));
        } else {

          console.log("req",req.body)

          let findUser = req.body

          let userRegistrationData = {
            firstName: findUser.firstName ,
            lastName: findUser.lastName ,
            email: findUser.email,
            emailSecondary: findUser.emailSecondary,
            dob: findUser?.dob,
            nationality: findUser?.nationality,
            phone1: findUser?.phone,
            
            address: {
              address1 : findUser?.address1,
              address2 : findUser?.address2,
              city : findUser?.city,
              state : findUser?.state,
              country : findUser?.country,
              zip : findUser?.zip
            },
            gender: findUser?.gender,
            fatherName: findUser?.fatherName,
            motherName: findUser?.motherName,
            userId : findUser?.userId,
            bloodGroup: findUser?.bloodGroup,
            employeePhoto : findUser?.passportPhoto,
            adharcardNo : findUser?.adharno,
            pancardNo   : findUser?.pancard ,
            officialEmail : findUser?.officialEmail,
            department : findUser?.department,
            designation : findUser?.designation,
            workType : findUser?.workType,
            joiningDate : findUser?.joiningDate,
            reportingTo : findUser?.reportingTo,
            previousEmployeeDetails : {
              prevEmploymentType : findUser?.prevEmploymentType ,
              prevOfficeBranch : findUser?.prevOfficeBranch,
              prevOfficeAddress : findUser?.prevOfficeAddress ,
              prevOfficeContactNo : findUser?.prevOfficeContactNo ,
              prevOfficeEmailId : findUser?.prevOfficeEmailId ,
              prevDesignation : findUser?.prevDesignation , 
              prevPFAccountNo:  findUser?.prevPFAccountNo  ,
              prevUANNo  : findUser?.prevUANNo ,
              prevESINo : findUser?.prevESINo ,
              leavingDate :findUser?.leavingDate , 
              prevAnnualSalary : findUser?.prevAnnualSalary,
              payslips : findUser?.payslips,
              resignationForm : findUser?.resignationForm
            },
            bankinformation: {
              bankAccountNo: findUser?.bankAccountNo ,
              bankName: findUser?.bankName,
              bankBranch: findUser?.bankBranch,
              ifscCode: findUser?.ifscCode,
            },
        
            emergencyContact: {
  
              emergencyContactEmail: findUser?.emergencyContactEmail,
              emergencyContactName1: findUser?.emergencyContactName1,
              emergencyContactRalationship1: findUser?.emergencyContactRalationship1,
              emergencyContactPhon1: findUser?.emergencyContactPhon1,
              emergencyContactName2: findUser.emergencyContactName2,
              emergencyContactRalationship2: findUser.emergencyContactRalationship2,
              emergencyContactPhon2: findUser.emergencyContactPhon2,
            },
            assignedCountry: findUser?.assignedCountry
          };

          console.log(userRegistrationData , "check")

          let updateUser = await global.models.GLOBAL.USER.findByIdAndUpdate(
            findUser1._id,
            userRegistrationData
          );

          console.log("update user" , updateUser)
          if (!updateUser) {
            let data4createResponseObject = {
              req: req,
              result: -1,
              message: messages.USER_UPDATE_FAILED,
              payload: {},
              logPayload: false,
            };
            return res
              .status(enums.HTTP_CODES.BAD_REQUEST)
              .json(utils.createResponseObject(data4createResponseObject));
          } else {
            updateUser = await global.models.GLOBAL.USER.findOne({
              _id: id,
            }).select("-password -__v -updatedAt");
            let data4createResponseObject = {
              req: req,
              result: 0,
              message: messages.USER_UPDATED,
              payload: { updateUser: updateUser },
              logPayload: false,
            };
            return res
              .status(enums.HTTP_CODES.OK)
              .json(utils.createResponseObject(data4createResponseObject));
          }
        }
      } catch (error) {
        logger.error(
          `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
        );
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.GENERAL,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
          .json(utils.createResponseObject(data4createResponseObject));
      }
    }
  },
};
