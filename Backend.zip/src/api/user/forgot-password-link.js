const Joi = require("joi");

const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");

const logger = require("../../logger");
const utils = require("../../utils");
const crypto = require("crypto");
const nodemailer = require("nodemailer");

// User Profile update
module.exports = exports = {
  validation: Joi.object({
    email: Joi.string().required(),
  }),
  handler: async (req, res) => {
    const { email } = req.body;

    if (!email) {
      const data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.INVALID_PARAMETERS,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.BAD_REQUEST)
        .json(utils.createResponseObject(data4createResponseObject));
    }
    try {
      let findUser = await global.models.GLOBAL.USER.findOne({
        email: email,
      });
      if (!findUser) {
        const data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.USER_DOES_NOT_EXIST,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.BAD_REQUEST)
          .json(utils.createResponseObject(data4createResponseObject));
      } else {
        let token = crypto.randomBytes(32).toString("hex");

        let resetToken = token;
        let resetTokenExpires = Date.now() + 900000; // 15 minutes
        let addToken = await global.models.GLOBAL.USER.findByIdAndUpdate(
          findUser._id,
          {
            $set: {
              resetPasswordToken: resetToken,
              resetPasswordExpire: resetTokenExpires,
            },
          },
          { new: true }
        );
        if (!addToken) {
          const data4createResponseObject = {
            req: req,
            result: 0,
            message: messages.FORGOT_PASSWORD_FAILED,
            payload: {},
            logPayload: false,
          };
          return res
            .status(enums.HTTP_CODES.BAD_REQUEST)
            .json(utils.createResponseObject(data4createResponseObject));
        } else {
          console.log("MAIL SENDING");
          let transporter = nodemailer.createTransport({
            // service: "gmail",
            host: process.env.SMTP_HOST,
            port: process.env.SMTP_PORT,
            secure: false,
            auth: {
              user: process.env.SMTP_USERNAME,
              pass: process.env.SMTP_PASSWORD,
            },
          });
          let info = await transporter.sendMail({
            from: process.env.SMTP_FROM_EMAIL,
            to: email,
            subject: "CTG HRMS | Reset Password Link",
            text:
              "You are receiving this because you have requested the reset of the password for your account.\n\n" +
              "Please click on the following link, or paste this into your browser to complete the process:\n\n" +
              process.env.FRONTEND_URL +
              "/reset/" +
              token +
              "/" +
              email +
              "\n\n" +
              "If you did not request this, please ignore this email and your password will remain unchanged.\n",
          });
          console.log("Message sent: %s", info.messageId);

          const data4createResponseObject = {
            req: req,
            result: 0,
            message: messages.PASSWORD_LINK_SENT,
            payload: {},
            logPayload: false,
          };
          return res
            .status(enums.HTTP_CODES.OK)
            .json(utils.createResponseObject(data4createResponseObject));
        }
      }
    } catch (error) {
      logger.error(
        `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
      );
      const data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.GENERAL,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
        .json(utils.createResponseObject(data4createResponseObject));
    }
  },
};
