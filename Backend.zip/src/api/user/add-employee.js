const Joi = require("joi");
const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");
const logger = require("../../logger");
const utils = require("../../utils");
const nodemailer = require("nodemailer");

// User Registration
module.exports = exports = {
  // route validation
  // validation: Joi.object({

  //   employementType : Joi.string().required(),
  //   officeBranch : Joi.string().required(),
  //   officeAddress : Joi.string().required(),
  //   officeContactNo : Joi.string().required(),
  //   officeEmail : Joi.string().required() ,
  //   designation : Joi.string().required()  , 
  //   pfAccountNo : Joi.string().required()  ,
  //   unaNo : Joi.string().required()  ,
  //   esiNo : Joi.string().required()  ,
  //   leavingDate : Joi.date().required()  , 
  //   annualSalary : Joi.string().required()  , 
  //   // payslips : Joi.string().required()  , 
  //   // resignationForm : Joi.string().required(),
        
  //   firstName: Joi.string().required(),
  //   lastName: Joi.string().required(),
  //   email: Joi.string().required(),
  //   dob: Joi.date().allow(""),
  //   nationality: Joi.string().allow(""),
  //   address: Joi.string().allow(""),
  //   gender: Joi.string().allow(""),
  //   countryCode: Joi.string().required(),
  //   fatherName: Joi.string().allow(""),
  //   motherName: Joi.string().allow(""),
  //   bloodGroup: Joi.string().allow(""),
  // }),

  // route handler
  handler: async (req, res) => {

    console.log("req body" , req.body)


    const {
      firstName,
      lastName,
      email,
      emailSecondary,
      dob,
      nationality,
      phone,
      address1,
      address2,city , state,country ,zip,
      gender,
      // countryCode,
      bloodGroup,
      motherName,
      fatherName,
      prevEmploymentType ,
      prevOfficeBranch,
      prevOfficeAddress ,
      prevOfficeContactNo ,
      prevOfficeEmailId ,
      prevDesignation , 
      prevPFAccountNo  ,
      prevUANNo  ,
      prevESINo ,
      leavingDate, 
      prevAnnualSalary,
      resignationForm , 
      // payslips,
      payslipMonth1,
      payslipMonth2,
      payslipMonth3,
      bankAccountNo,
      bankBranch ,
      bankName ,
      ifscCode ,
      emergencyContactEmail ,
      emergencyContactName1,
      emergencyContactRalationship1,
      emergencyContactPhon1,
      emergencyContactName2 ,
      emergencyContactRalationship2,
      emergencyContactPhon2,
      pancard,
      adharno,
      passportPhoto,
      officialEmail,
      department,
      designation,
      workType,
      joiningDate,
      reportingTo,
      assignedCountry


    } = req.body;
    const role = req.body.role ? req.body.role : "employee";

    if (
      !firstName ||
      !lastName ||
      !email ||
      !emailSecondary ||
      !dob ||
      !nationality ||
      !phone ||
      !address1 || !address2 || !city || !state || !country || !zip ||
      !gender ||
      !bloodGroup ||
      !motherName || 
      !fatherName ||
      !pancard ||
      !adharno || 
      !passportPhoto || 
      (
        ( bankAccountNo || bankBranch || bankName || ifscCode) && ( !bankAccountNo || !bankBranch || !bankName || !ifscCode)
      )
      
      // !countryCode
    ) {
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.INVALID_PARAMETERS,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.BAD_REQUEST)
        .json(utils.createResponseObject(data4createResponseObject));
    }

    try {
      let findUser = await global.models.GLOBAL.USER.find({
        $or: [{ email: email }, { phone: phone }],
      });
      if (findUser.length > 0) {
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.EMPLOYEE_ALREADY_EXIST,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.DUPLICATE_VALUE)
          .json(utils.createResponseObject(data4createResponseObject));
      } else {
        var autoPassword =  utils.generatePassword()
        var autoHashPassword = utils.passwordHash(autoPassword)
        var autoUserId = Math.floor(Math.random() * 100000000)


        let userRegistrationDate = {
          firstName: firstName,
          lastName: lastName,
          email: email,
          emailSecondary:  emailSecondary,
          dob: dob,
          nationality: nationality,
          role: role,
          phone: phone,
          address: {
            address1 : address1,
            address2 : address2 , 
            city : city , 
            state : state,
            country : country,
            zip : zip
          },
          gender: gender,
          createdAt: Date.now(),
          fatherName: fatherName,
          motherName: motherName,
          bloodGroup: bloodGroup,
          pancardNo : pancard?.Location,
          adharcardNo : adharno?.Location,
          employeePhoto : passportPhoto?.Location,

          officialEmail : officialEmail,
          designation : designation , 
          department : department ,
          workType : workType , 
          joiningDate : joiningDate,
          reportingTo : reportingTo,
          userId : autoUserId,
          password : autoHashPassword,

          previousEmployeeDetails : {
            prevEmploymentType : prevEmploymentType ,
            prevOfficeBranch : prevOfficeBranch,
            prevOfficeAddress : prevOfficeAddress ,
            prevOfficeContactNo : prevOfficeContactNo ,
            prevOfficeEmailId : prevOfficeEmailId ,
            prevDesignation : prevDesignation , 
            prevPFAccountNo:  prevPFAccountNo  ,
            prevUANNo  : prevUANNo ,
            prevESINo : prevESINo ,
            leavingDate :leavingDate , 
            prevAnnualSalary : prevAnnualSalary,
            // payslips : payslips?.Location,
            payslipMonth1: payslipMonth1?.Location,
            payslipMonth2: payslipMonth2?.Location,
            payslipMonth3: payslipMonth3?.Location,
            resignationForm : resignationForm?.Location
          },
          bankinformation: {
            bankAccountNo: bankAccountNo ,
            bankName: bankName,
            bankBranch: bankBranch,
            ifscCode: ifscCode,
          },


      
          emergencyContact: {

            emergencyContactEmail: emergencyContactEmail,
            emergencyContactName1: emergencyContactName1,
            emergencyContactRalationship1: emergencyContactRalationship1,
            emergencyContactPhon1: emergencyContactPhon1,
            emergencyContactName2: emergencyContactName2,
            emergencyContactRalationship2: emergencyContactRalationship2,
            emergencyContactPhon2: emergencyContactPhon2,
          },
          assignedCountry: assignedCountry
        };


        console.log("data crateion" , userRegistrationDate)
        const newUser = await global.models.GLOBAL.USER.create(
          userRegistrationDate
        );
        if (!newUser) {
          let data4createResponseObject = {
            req: req,
            result: -1,
            message: messages.USER_ADD_FAILED,
            payload: {},
            logPayload: false,
          };
          return res
            .status(enums.HTTP_CODES.BAD_REQUEST)
            .json(utils.createResponseObject(data4createResponseObject));
        } else {

              console.log("MAIL SENDING");
                    let transporter = nodemailer.createTransport({
                      // service: "gmail",
                      host: process.env.SMTP_HOST,
                      port: process.env.SMTP_PORT,
                      secure: false,
                      auth: {
                        user: process.env.SMTP_USERNAME,
                        pass: process.env.SMTP_PASSWORD,
                      },
                    });
                    let info = await transporter.sendMail({
                      from: process.env.SMTP_FROM_EMAIL,
                      to: newUser.email,
                      subject: "CTG HRMS | Added as an Employee Successfully",
                      text:
                        "You added by admin as an Employee is Successfully\n\n" +
                        "Your new Employee Id and Password is generated and given it below.Use it for login the portal\n\n" +
                        `Employee Id : ${autoUserId}\n\n` +
                        `Temparory Password : ${autoPassword}\n\n` +
                        "If you did not request this, please ignore this email and your password will remain unchanged.\n",
                    });

                  //  console.log(info)


          let data4createResponseObject = {
            req: req,
            result: 0,
            message: messages.USER_ADD_SUCCESS,
            payload: newUser,
            logPayload: false,
          };
          return res
            .status(enums.HTTP_CODES.OK)
            .json(utils.createResponseObject(data4createResponseObject));
        }
      }
    } catch (error) {
      logger.error(
        `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
      );
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.GENERAL,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
        .json(utils.createResponseObject(data4createResponseObject));
    }
  },
};
