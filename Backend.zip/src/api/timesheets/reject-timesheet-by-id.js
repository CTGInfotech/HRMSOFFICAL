const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");
const logger = require("../../logger");
const { sendRejectedTimesheetMail } = require("../../mailer");
const utils = require("../../utils");

// Delete User with the specified userId in the request
module.exports = exports = {
  // route handler
  handler: async (req, res) => {
    let { user } = req;
    const { user_id } = req.params;

    const {rejectionRemark} = req.body;

    console.log(rejectionRemark);
    console.log(req.params)

    if (!user_id) {
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.INVALID_PARAMETERS,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.BAD_REQUEST)
        .json(utils.createResponseObject(data4createResponseObject));
    }

    let criteria = {
        _id : user_id
    }

    if ( user.role !== enums.USER_TYPE.ADMIN && user.role !== enums.USER_TYPE.HR ) {
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.NOT_ALLOWED,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.METHOD_NOT_ALLOWED)
          .json(utils.createResponseObject(data4createResponseObject));
      }
    else
    {
        try {
            let findUser = await global.models.GLOBAL.TIMESHEET_FILL.findOne(criteria).populate("user");
      
            if (!findUser) {
              let data4createResponseObject = {
                req: req,
                result: -1,
                message: messages.TIMESHEET_DOES_NOT_EXIST,
                payload: {},
                logPayload: false,
              };
              return res
                .status(enums.HTTP_CODES.NOT_FOUND)
                .json(utils.createResponseObject(data4createResponseObject));
            } else {
            //  let deleteUser = await global.models.GLOBAL.TIMESHEET_FILL.findByIdAndRemove(criteria);
               let updatedUser=await global.models.GLOBAL.TIMESHEET_FILL.findByIdAndUpdate(criteria,{status: 'REJECTED',rejectionRemark: rejectionRemark});

              if (!updatedUser) {
                let data4createResponseObject = {
                  req: req,
                  result: -1,
                  message: messages.TIMESHEET_REJECTED,
                  payload: {},
                  logPayload: false,
                };
                return res
                  .status(enums.HTTP_CODES.BAD_REQUEST)
                  .json(utils.createResponseObject(data4createResponseObject));
              } else {
                await sendRejectedTimesheetMail(findUser.user.email,findUser.month);
                if(findUser.user.officialEmail)
                await sendRejectedTimesheetMail(findUser.user.officialEmail,findUser.month);
                let data4createResponseObject = {
                  req: req,
                  result: 0,
                  message: messages.TIMESHEET_REJECTED,
                  payload: {},
                  logPayload: false,
                };
                return res
                  .status(enums.HTTP_CODES.OK)
                  .json(utils.createResponseObject(data4createResponseObject));
              }
            }
          } catch (error) {
            logger.error(
              `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
            );
            let data4createResponseObject = {
              req: req,
              result: -1,
              message: messages.GENERAL,
              payload: {},
              logPayload: false,
            };
            res
              .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
              .json(utils.createResponseObject(data4createResponseObject));
          }
    }



  },
};
