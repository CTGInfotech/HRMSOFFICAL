const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");

const logger = require("../../logger");
const utils = require("../../utils");

// Get User by ID
module.exports = exports = {
  handler: async (req, res) => {
    const { user } = req;
    try {
      let { user_id } = req.params;
      let {timesheet} = req.body;
      if (!user_id || !timesheet) {
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.INVALID_PARAMETERS,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.BAD_REQUEST)
          .json(utils.createResponseObject(data4createResponseObject));
      }

      if ( user.role !== enums.USER_TYPE.ADMIN && user.role !== enums.USER_TYPE.HR ) {
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.NOT_ALLOWED,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.METHOD_NOT_ALLOWED)
          .json(utils.createResponseObject(data4createResponseObject));
      }
      else
      {
        let criteria = {}
        if (user_id) {
          criteria = {
              _id: user_id,
          };
        }
        
        let findOnboardingEmployee = await global.models.GLOBAL.TIMESHEET_FILL.findOne(criteria)
        
        if (!findOnboardingEmployee) {
          let data4createResponseObject = {
            req: req,
            result: -1,
            message: messages.TIMESHEET_DOES_NOT_EXIST,
            payload: {},
            logPayload: false,
          };
          return res
            .status(enums.HTTP_CODES.NOT_FOUND)
            .json(utils.createResponseObject(data4createResponseObject));
        } else {

            let updateTimesheetStatus = await global.models.GLOBAL.TIMESHEET_FILL.findOneAndUpdate(criteria , { timesheet : timesheet})
            console.log("updated status" , updateTimesheetStatus)

            updateTimesheetStatus = JSON.parse(JSON.stringify(updateTimesheetStatus));
          let data4createResponseObject = {
            req: req,
            result: 0,
            message: messages.TIMESHEET_APPROVED,
            payload : updateTimesheetStatus,
            logPayload: false,
          };
          return res
            .status(enums.HTTP_CODES.OK)
            .json(utils.createResponseObject(data4createResponseObject));
        }
      }

    
    } catch (error) {
      logger.error(
        `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
      );
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.GENERAL,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
        .json(utils.createResponseObject(data4createResponseObject));
    }
  },
};
