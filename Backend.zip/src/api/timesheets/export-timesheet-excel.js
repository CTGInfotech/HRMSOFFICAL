const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");

const logger = require("../../logger");
const utils = require("../../utils");
const writeXlsxFile = require('write-excel-file/node')


const schema = [
  {
    column: 'Date',
    type: String,
    value: item => item.date
  },
  {
    column: 'Day',
    width:10,
    type: String,
    value: item => item.day
  },
  {
    column: 'Work Hrs',
    type: Number,
    width:10,
    value: item => item.work_hrs
  },
  {
      column: 'Away Hrs',
      type: Number,
      width:10,
      value: item => item.away_hrs
    },
  {
    column: 'Client',
    width:20,
    type: String,
    value: item => item.clientId ? item.clientId.clientName : ''
  },
  {
      column: 'Project',
      type: String,
      width:20,
      value: item => item.projectId ? item.clientId.clientName : ''
    },
    {
      column: 'Description',
      type: String,
      width:100,
      value: item => item.description
    },

]
// Get User by ID
module.exports = exports = {
  handler: async (req, res) => {
    const { user } = req;
    try {
      let { timesheetId } = req.params;
      
      if (!timesheetId) {
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.INVALID_PARAMETERS,
          payload: {},
          logPayload: false,
        };
        
        return res
          .status(enums.HTTP_CODES.BAD_REQUEST)
          .json(utils.createResponseObject(data4createResponseObject));
      }


      let criteria;
        criteria = {
            _id: timesheetId
        };
      

        let findOnboardingEmployee = await global.models.GLOBAL.TIMESHEET_FILL.findOne(criteria).populate('user').populate('timesheet.clientId').populate('timesheet.projectId');

         console.log(findOnboardingEmployee.timesheet);
        if (!findOnboardingEmployee) {
          let data4createResponseObject = {
            req: req,
            result: -1,
            message: messages.TIMESHEET_DOES_NOT_EXIST,
            payload: {},
            logPayload: false,
          };
          return res
            .status(enums.HTTP_CODES.NOT_FOUND)
            .json(utils.createResponseObject(data4createResponseObject));
        } else {
            findOnboardingEmployee = JSON.parse(JSON.stringify(findOnboardingEmployee));
            
            var xlsx = await writeXlsxFile(findOnboardingEmployee.timesheet, { 
              schema,
              stickyRowsCount: 1,
              headerStyle: {
                  backgroundColor: '#eeeeee',
                  fontWeight: 'bold',
                  align: 'center'
                },
            });
            
            res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            res.setHeader('Content-Disposition', 'attachment; filename='+findOnboardingEmployee.user.userId +'-'+findOnboardingEmployee.month+'-'+'timehseet.xlsx');
            xlsx.pipe(res);
            return;
        }
    } catch (error) {
      logger.error(
        `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
      );
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.GENERAL,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
        .json(utils.createResponseObject(data4createResponseObject));
    }
  },
};
