const timesheetFilled = require("./timesheet-filled")
const getTimesheetByMonth = require("./get-timesheet-by-date")
const getAllTimesheetForApproveByMonth = require("./get-all-timesheet-by-date")
const isValidDateForFIllTimesheet = require("./isvalid-date-for-selectedDate")
const approvedTimesheetById = require("./approve-timesheet-by-id")
const rejectTimesheetById = require("./reject-timesheet-by-id")
const updateTimesheetById = require("./update-timesheet-by-admin")
const saveTimesheetDraft=require("./timesheet-save-draft")
const exportTimesheetPdf = require("./export-timesheet-pdf");
const exportTimesheetExcel = require("./export-timesheet-excel");
const exportConsolidatedReportPdf=require("./export-consolidatedReport-pdf")
const consolidatedReportPdf=require("./consolidated_pdf");
const exportConsolidatedTimesheetPdf=require('./export-consolidated_timesheetPdf');
const exportConsolidatedReportExcel=require("./export-consolidatedReport-excel")
const exportConsolidatedTimesheetExcel=require("./export-consolidated-timesheet-excel");

module.exports = exports = {
    timesheetFilled,
    getTimesheetByMonth,
    getAllTimesheetForApproveByMonth,
    isValidDateForFIllTimesheet,
    approvedTimesheetById,
    rejectTimesheetById,
    updateTimesheetById,
    saveTimesheetDraft,
    exportTimesheetPdf,
    exportTimesheetExcel,
    exportConsolidatedReportExcel,
    exportConsolidatedReportPdf,
    exportConsolidatedTimesheetPdf,
    exportConsolidatedTimesheetExcel,
    consolidatedReportPdf
};
