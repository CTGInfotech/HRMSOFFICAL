const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");

const logger = require("../../logger");
const utils = require("../../utils");
const writeXlsxFile = require('write-excel-file/node');
const { forEach } = require("lodash");



const schema = [
    {
      column: 'Date',
      type: String,
      value: item => item.date
    },
    {
      column: 'Day',
      width:10,
      type: String,
      value: item => item.day
    },
    {
      column: 'Work Hrs',
      type: Number,
      width:10,
      value: item => item.work_hrs
    },
    {
        column: 'Away Hrs',
        type: Number,
        width:10,
        value: item => item.away_hrs
      },
      {
        column: 'Description',
        type: String,
        width:100,
        value: item => item.description
      }
  ]



module.exports = exports = {
  handler: async (req, res) => {
    let { user } = req;

    const {
        month,
        clientName,
        projectName
    } = req.body;

    console.log(month,clientName,projectName)
    
    if (
        !month ||
        !clientName
    ) {
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.INVALID_PARAMETERS,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.BAD_REQUEST)
        .json(utils.createResponseObject(data4createResponseObject));
    }
    try {
          //Array of timesheets where month is given by user..
      let findUser = await global.models.GLOBAL.TIMESHEET_FILL.find({month: month}).populate('user').lean();
      
      if(!findUser)
      {
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: "Some error occured in fetching data!",
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.BAD_REQUEST)
          .json(utils.createResponseObject(data4createResponseObject));

      }else{
            let filteredData=[];
            let totalWorkHours=0;
            findUser.forEach(element => {
              let workHrs=0;
              let thisTimesheet=[];
              element.timesheet.forEach((singleTimesheet)=>{
                      if((projectName==='' || !projectName) && singleTimesheet.clientId==clientName)
                      {
                          workHrs+=singleTimesheet.work_hrs;
                          thisTimesheet.push(singleTimesheet);
                      }
                      else if(singleTimesheet.clientId==clientName && singleTimesheet.projectId==projectName)
                      {
                          workHrs+=singleTimesheet.work_hrs;
                          thisTimesheet.push(singleTimesheet);
                      }
              })
              if(workHrs>0)
              {
                    totalWorkHours+=workHrs;
                filteredData.push(
                       thisTimesheet
                      );
              } 
            });
           // filteredData.push(filteredData[0]);
            let schemaArray=[];
            let sheets=[];
            let count=1;
            filteredData.forEach((data)=>{
                 schemaArray.push(schema);
                 sheets.push("sheet" + count);
                 count+=1;
            })
              
             var xlsx = await writeXlsxFile([...filteredData], { 
                schema: schemaArray,
                sheets,
                stickyRowsCount: 1,
                headerStyle: {
                    backgroundColor: '#eeeeee',
                    fontWeight: 'bold',
                    align: 'center'
                  },
              });
              
              res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
              res.setHeader('Content-Disposition', 'attachment; filename='+clientName+month+'timehseet.xlsx');
              xlsx.pipe(res);
              return;
      }
    } catch (error) {
      logger.error(
        `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
      );
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.GENERAL,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
        .json(utils.createResponseObject(data4createResponseObject));
    }
  },
};
