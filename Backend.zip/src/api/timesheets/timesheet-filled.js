const { boolean } = require("joi");
const Joi = require("joi");
const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");
const logger = require("../../logger");
const utils = require("../../utils");

// User Registration
module.exports = exports = {
  // route validation
  validation: Joi.object({
  }),

  // route handler
  handler: async (req, res) => {

    let { user } = req;

    const {
        month ,
        timesheet
    } = req.body;

    console.log( month , "month" , timesheet)
    
    if (
        !month ||
        !timesheet
    ) {
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.INVALID_PARAMETERS,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.BAD_REQUEST)
        .json(utils.createResponseObject(data4createResponseObject));
    }

    try {
      let findUser = await global.models.GLOBAL.TIMESHEET_FILL.findOne({
        $and: [{ user : user._id }, { month : month }],
      });
  
      if (findUser) {

        let userTimeSheet= findUser;
        userTimeSheet = JSON.parse(JSON.stringify(userTimeSheet));

        if(userTimeSheet.status==='REJECTED' || userTimeSheet.status==='DRAFT' || userTimeSheet.status==='FILLED')
        {
           const Data=await global.models.GLOBAL.TIMESHEET_FILL.findOneAndUpdate({user: user._id,month: month,status: userTimeSheet.status},{timesheet,status: 'FILLED'});
           
           if(!Data)
           {
            let data4createResponseObject = {
                req: req,
                result: -1,
                message: messages.TIMESHEET_FILLED_FAILED,
                payload: {},
                logPayload: false,
              };
              return res
                .status(enums.HTTP_CODES.BAD_REQUEST)
                .json(utils.createResponseObject(data4createResponseObject));
           }
           
           let data4createResponseObject = {
            req: req,
            result: 0,
            message: messages.TIMESHEET_FILLED_SUCCESS,
            payload: Data,
            logPayload: false,
          };
          return res
            .status(enums.HTTP_CODES.OK)
            .json(utils.createResponseObject(data4createResponseObject));
        }else{
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.TIMESHEET_ALREADY_EXIST,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.DUPLICATE_VALUE)
          .json(utils.createResponseObject(data4createResponseObject));
        }
      } else {
          let timesheet_arr = []
          timesheet.map((val) => {
              timesheet_arr.push({
                  date : val.date,
                  day : val.day,
                  work_hrs : val.work_hrs,
                  away_hrs : val.away_hrs,
                  description : val.description,
                  projectId: val.projectId,
                  clientId: val.clientId
              })
          })
        let timesheetData = {
            user : user._id,
            month : month,
            timesheet : timesheet_arr,
            role : user.role
        }

        const newTimesheetFilled = await global.models.GLOBAL.TIMESHEET_FILL.create(
          timesheetData
        );
        if (!newTimesheetFilled) {
          let data4createResponseObject = {
            req: req,
            result: -1,
            message: messages.TIMESHEET_FILLED_FAILED,
            payload: {},
            logPayload: false,
          };
          return res
            .status(enums.HTTP_CODES.BAD_REQUEST)
            .json(utils.createResponseObject(data4createResponseObject));
        } else {
          let data4createResponseObject = {
            req: req,
            result: 0,
            message: messages.TIMESHEET_FILLED_SUCCESS,
            payload: newTimesheetFilled,
            logPayload: false,
          };
          return res
            .status(enums.HTTP_CODES.OK)
            .json(utils.createResponseObject(data4createResponseObject));
        }
      }
    } catch (error) {
      logger.error(
        `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
      );
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.GENERAL,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
        .json(utils.createResponseObject(data4createResponseObject));
    }
  },
};
