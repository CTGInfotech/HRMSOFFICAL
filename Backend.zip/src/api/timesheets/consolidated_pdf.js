const { boolean } = require("joi");
const Joi = require("joi");
const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");
const logger = require("../../logger");
const utils = require("../../utils");

// User Registration
module.exports = exports = {
  // route validation
  validation: Joi.object({
  }),

  // route handler
  handler: async (req, res) => {

    let { user } = req;

    const {
        month ,
        clientName,
        projectName
    } = req.body;

    console.log(month,clientName,projectName)
    
    if (
        !month ||
        !clientName
    ) {
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.INVALID_PARAMETERS,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.BAD_REQUEST)
        .json(utils.createResponseObject(data4createResponseObject));
    }

    try {
      //Array of timesheets where month is given by user..
      let findUser = await global.models.GLOBAL.TIMESHEET_FILL.find({month: month}).populate('user');
      
      if(!findUser)
      {
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: "Some error occured in fetching data!",
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.BAD_REQUEST)
          .json(utils.createResponseObject(data4createResponseObject));

      }else{
            let filteredData=[];
            let totalWorkHours=0;
            findUser.forEach(element => {
              let workHrs=0;
              element.timesheet.forEach((singleTimesheet)=>{
                      if((projectName==='' || !projectName) && singleTimesheet.clientId==clientName)
                      {
                          workHrs+=singleTimesheet.work_hrs;
                      }
                      else if(singleTimesheet.clientId==clientName && singleTimesheet.projectId==projectName)
                      {
                          workHrs+=singleTimesheet.work_hrs;
                      }
              })
              if(workHrs>0)
              {
                    totalWorkHours+=workHrs;
                    filteredData.push({Employee_ID: element?.user?.userId,Employee_Name: element?.user?.firstName,workHours: workHrs});
              } 
            });

            let data4createResponseObject = {
              req: req,
              result: 0,
              message: 'Successfully fetched the data',
              payload: {filteredData,totalWorkHours},
              logPayload: false,
            };

            return res
              .status(enums.HTTP_CODES.OK)
              .json(utils.createResponseObject(data4createResponseObject));
      }
    } catch (error) {
      logger.error(
        `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
      );
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.GENERAL,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
        .json(utils.createResponseObject(data4createResponseObject));
    }
  },
};
