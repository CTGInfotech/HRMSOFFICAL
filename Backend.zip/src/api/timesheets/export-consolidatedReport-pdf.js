const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");

const logger = require("../../logger");
const utils = require("../../utils");
var pdf = require("pdf-creator-node");
var fs = require("fs");
const { filter } = require("lodash");


var options = {
  format: "A2",
  orientation: "landscape",
  border: "10mm",
};
var html = fs.readFileSync(require('path').resolve(__dirname,"../../../template/consolidatedReport.html"), "utf8");
// Get User by ID
module.exports = exports = {
  handler: async (req, res) => {
    const { user } = req;

    try {
        const {
            month ,
            clientName,
            projectName,
            filteredData,
            workHours
        } = req.body;
    
        console.log(month,clientName,projectName,filteredData,workHours);
        
        if (
            !month ||
            !clientName || !filteredData 
        ) {
          let data4createResponseObject = {
            req: req,
            result: -1,
            message: messages.INVALID_PARAMETERS,
            payload: {},
            logPayload: false,
          };
          return res
            .status(enums.HTTP_CODES.BAD_REQUEST)
            .json(utils.createResponseObject(data4createResponseObject));
        }

     
            var document = {
              html: html, 
              data: {
                data: filteredData,
                clientName,
                projectName,
                month,
                WorkHours: workHours
              },
              path: "./output.pdf",
              type: "stream",
            };
            let f = await pdf.create(document,options);
            
            res.setHeader('Content-Type', 'application/pdf');
            res.setHeader('Content-Disposition', 'attachment; filename='+'-'+month+'-'+'ConsolidatedTimehseet.pdf');
            f.pipe(res);
            return;
        
    } catch (error) {
      logger.error(
        `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
      );
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.GENERAL,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
        .json(utils.createResponseObject(data4createResponseObject));
    }
  },
};
