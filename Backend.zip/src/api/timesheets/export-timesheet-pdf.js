const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");

const logger = require("../../logger");
const utils = require("../../utils");
var pdf = require("pdf-creator-node");
var fs = require("fs");


var options = {
  format: "A2",
  orientation: "landscape",
  border: "10mm",
};
var html = fs.readFileSync(require('path').resolve(__dirname,"../../../template/timesheet.html"), "utf8");
// Get User by ID
module.exports = exports = {
  handler: async (req, res) => {
    const { user } = req;
    try {
      let { timesheetId } = req.params;
      
      if (!timesheetId) {
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.INVALID_PARAMETERS,
          payload: {},
          logPayload: false,
        };
        
        return res
          .status(enums.HTTP_CODES.BAD_REQUEST)
          .json(utils.createResponseObject(data4createResponseObject));
      }


      let criteria;
        criteria = {
            _id: timesheetId
        };
      

        let findOnboardingEmployee = await global.models.GLOBAL.TIMESHEET_FILL.findOne(criteria).populate('user').populate('timesheet.clientId').populate('timesheet.projectId');
        console.log("Data bejdej ")
        console.log(findOnboardingEmployee);

        // console.log(findOnboardingEmployee);
        if (!findOnboardingEmployee) {
          let data4createResponseObject = {
            req: req,
            result: -1,
            message: messages.TIMESHEET_DOES_NOT_EXIST,
            payload: {},
            logPayload: false,
          };
          return res
            .status(enums.HTTP_CODES.NOT_FOUND)
            .json(utils.createResponseObject(data4createResponseObject));
        } else {
            findOnboardingEmployee = JSON.parse(JSON.stringify(findOnboardingEmployee));
            const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
            let date = new Date(findOnboardingEmployee.month)

            var document = {
              html: html, 
              data: {
                data: findOnboardingEmployee.timesheet,
                user: findOnboardingEmployee.user,
                month: months[date.getMonth()],
                year: date.getFullYear().toString()
              },
              path: "./output.pdf",
              type: "stream",
            };

            let f = await pdf.create(document,options);
            
            res.setHeader('Content-Type', 'application/pdf');
            res.setHeader('Content-Disposition', 'attachment; filename='+findOnboardingEmployee.user.userId +'-'+findOnboardingEmployee.month+'-'+'timehseet.pdf');
            f.pipe(res);
            return;
        }
    } catch (error) {
      logger.error(
        `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
      );
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.GENERAL,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
        .json(utils.createResponseObject(data4createResponseObject));
    }
  },
};
