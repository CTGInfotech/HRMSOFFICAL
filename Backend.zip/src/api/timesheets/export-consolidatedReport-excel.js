const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");

const logger = require("../../logger");
const utils = require("../../utils");
const writeXlsxFile = require('write-excel-file/node')


const schema = [
  {
    column: 'Employee ID',
    type: Number,
    width: 30,
    value: item => item.Employee_ID
  },
  {
    column: 'Employee Name',
    width:50,
    type: String,
    value: item => item.Employee_Name
  },
  {
    column: 'Work Hours',
    type: Number,
    width:30,
    value: item => item.workHours
  }
]

module.exports = exports = {
  handler: async (req, res) => {
    try {

            const {
                month ,
                clientName,
                projectName,
                filteredData,
                workHours
            } = req.body;
        
            console.log(month,clientName,projectName,filteredData,workHours);
            
            if (
                !month ||
                !clientName || !projectName || !filteredData 
            ) {
            let data4createResponseObject = {
                req: req,
                result: -1,
                message: messages.INVALID_PARAMETERS,
                payload: {},
                logPayload: false,
            };
            return res
                .status(enums.HTTP_CODES.BAD_REQUEST)
                .json(utils.createResponseObject(data4createResponseObject));
            }
   

            var xlsx = await writeXlsxFile(filteredData, { 
              schema,
              stickyRowsCount: 1,
              headerStyle: {
                  backgroundColor: '#eeeeee',
                  fontWeight: 'bold',
                  align: 'center'
                },
            });
            
            res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            res.setHeader('Content-Disposition', 'attachment; filename='+clientName +'-'+month+'-'+'timehseet.xlsx');
            xlsx.pipe(res);
            return;
        
    } catch (error) {
      logger.error(
        `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
      );
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.GENERAL,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
        .json(utils.createResponseObject(data4createResponseObject));
    }
  },
};
