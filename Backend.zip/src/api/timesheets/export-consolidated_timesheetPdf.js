const { boolean } = require("joi");
const Joi = require("joi");
const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");
const logger = require("../../logger");
const utils = require("../../utils");
var pdf = require("pdf-creator-node");
var fs = require("fs");


var options = {
    format: "A2",
    orientation: "landscape",
    border: "10mm",
  };
  var html = fs.readFileSync(require('path').resolve(__dirname,"../../../template/consolidatedTimesheet.html"), "utf8");
// User Registration
module.exports = exports = {
  // route validation
  validation: Joi.object({
  }),

  // route handler
  handler: async (req, res) => {

    let { user } = req;

    const {
        month,
        clientName,
        projectName
    } = req.body;

    console.log(month,clientName,projectName)
    
    if (
        !month ||
        !clientName
    ) {
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.INVALID_PARAMETERS,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.BAD_REQUEST)
        .json(utils.createResponseObject(data4createResponseObject));
    }

    try {
      //Array of timesheets where month is given by user..
      let findUser = await global.models.GLOBAL.TIMESHEET_FILL.find({month: month}).populate('user').lean();
      
      if(!findUser)
      {
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: "Some error occured in fetching data!",
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.BAD_REQUEST)
          .json(utils.createResponseObject(data4createResponseObject));

      }else{
            let filteredData=[];
            let totalWorkHours=0;
            findUser.forEach(element => {
              let workHrs=0;
              let thisTimesheet=[];
              element.timesheet.forEach((singleTimesheet)=>{
                      if((projectName==='' || !projectName) && singleTimesheet.clientId==clientName)
                      {
                          workHrs+=singleTimesheet.work_hrs;
                          thisTimesheet.push(singleTimesheet);
                      }
                      else if(singleTimesheet.clientId==clientName && singleTimesheet.projectId==projectName)
                      {
                          workHrs+=singleTimesheet.work_hrs;
                          thisTimesheet.push(singleTimesheet);
                      }
              })
              if(workHrs>0)
              {
                    totalWorkHours+=workHrs;
                    filteredData.push({
                        user: element.user,
                        data: thisTimesheet,
                        month: month
                    });
              } 
            });
            
            // if(filteredData.length > 0)
            // {
            //     filteredData.push(filteredData[0]);
            //     filteredData.push(filteredData[0]);
            // }
         
            var document = {
                html: html, 
                data: {
                  data: filteredData
                },
                path: "./output.pdf",
                type: "stream",
              };
  
              let f = await pdf.create(document,options);
              
              res.setHeader('Content-Type', 'application/pdf');
              res.setHeader('Content-Disposition', 'attachment; filename='+clientName +'-'+month+'-'+'ConsolidatedTimehseet.pdf');
              f.pipe(res);
              return;
      }
    } catch (error) {
      logger.error(
        `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
      );
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.GENERAL,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
        .json(utils.createResponseObject(data4createResponseObject));
    }
  },
};
