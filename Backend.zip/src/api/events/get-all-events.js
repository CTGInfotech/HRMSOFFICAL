const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");

const logger = require("../../logger");
const utils = require("../../utils");

// Get Events
module.exports = exports = {
  handler: async (req, res) => {
    try {
      let { id } = req.query;
      let criteria;
      if (id) {
        criteria = {
          _id: id,
        };
      }

      let page = req.query.page ? parseInt(req.query.page) : 1;
      let limit = req.query.limit ? parseInt(req.query.limit) : 10;
      let skip = (page - 1) * limit;

      let findEvents = await global.models.GLOBAL.EVENTS.find(criteria)
        .skip(skip)
        .limit(limit)
        .sort({
          startDate: -1,
        });

      let total = await global.models.GLOBAL.EVENTS.countDocuments(criteria);

      if (!findEvents) {
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.EVENT_NOT_FOUND,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.NOT_FOUND)
          .json(utils.createResponseObject(data4createResponseObject));
      } else {
        findEvents = JSON.parse(JSON.stringify(findEvents));
        let data4createResponseObject = {
          req: req,
          result: 0,
          message: messages.EVENT_FETCHED,
          payload: { findEvents, page: page, limit: limit, count: total },
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.OK)
          .json(utils.createResponseObject(data4createResponseObject));
      }
    } catch (error) {
      logger.error(
        `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
      );
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.GENERAL,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
        .json(utils.createResponseObject(data4createResponseObject));
    }
  },
};
