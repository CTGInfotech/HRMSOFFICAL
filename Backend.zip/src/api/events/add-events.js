const Joi = require("joi");
const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");
const logger = require("../../logger");
const utils = require("../../utils");

// Event Create
module.exports = exports = {
  // route validation
  validation: Joi.object({
    name: Joi.string().required(),
    description: Joi.string().allow(""),
    startDate: Joi.date().required(),
    endDate: Joi.date().allow(""),
    isActive: Joi.boolean().allow(""),
    duration: Joi.string().required(),
    location: Joi.string().required(),
    eventTime: Joi.string().required(),
    calenderColor: Joi.string().required(),
  }),

  // route handler
  handler: async (req, res) => {
    const { user } = req;
    const {
      name,
      description,
      startDate,
      endDate,
      duration,
      location,
      eventTime,
      calenderColor,
    } = req.body;
    const isActive = req.body.isActive || false;

    if (
      !name ||
      !startDate ||
      !duration ||
      !location ||
      !eventTime ||
      !calenderColor
    ) {
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.INVALID_PARAMETERS,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.BAD_REQUEST)
        .json(utils.createResponseObject(data4createResponseObject));
    }

    try {
      let eventsData = {
        name: name,
        description: description,
        startDate: startDate,
        endDate: endDate ? endDate : null,
        isActive: isActive,
        postDate: new Date(),
        postBy: user._id,
        duration: duration,
        location: location,
        eventTime: eventTime,
        calenderColor: calenderColor,
      };
      if (
        user.role !== enums.USER_TYPE.ADMIN &&
        user.role !== enums.USER_TYPE.HR
      ) {
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.NOT_ALLOWED,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.METHOD_NOT_ALLOWED)
          .json(utils.createResponseObject(data4createResponseObject));
      }

      const newEvent = await global.models.GLOBAL.EVENTS.create(eventsData);
      if (!newEvent) {
        let data4createResponseObject = {
          req: req,
          result: 0,
          message: messages.EVENT_CREATE_FAILED,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.BAD_REQUEST)
          .json(utils.createResponseObject(data4createResponseObject));
      } else {
        let data4createResponseObject = {
          req: req,
          result: 1,
          message: messages.EVENT_CREATED,
          payload: newEvent,
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.OK)
          .json(utils.createResponseObject(data4createResponseObject));
      }
    } catch (error) {
      logger.error(
        `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
      );
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.GENERAL,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
        .json(utils.createResponseObject(data4createResponseObject));
    }
  },
};
