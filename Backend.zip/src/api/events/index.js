const addEvents = require("./add-events");
const getEvents = require("./get-all-events");
const updateEvents = require("./update-event");
const deleteEvents = require("./delete-event");

module.exports = exports = {
  addEvents,
  getEvents,
  updateEvents,
  deleteEvents,
};
