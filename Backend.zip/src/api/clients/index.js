const addClient = require("./add-clients")
const getClients = require("./get-clients")
const myClients = require("./get-my-clients")
const deleteClietById = require("./delete-client")
const updateClientById = require("./update-client")
 
module.exports = exports = {
    addClient,
    getClients,
    myClients,
    updateClientById,
    deleteClietById
};
