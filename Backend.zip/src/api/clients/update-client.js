const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");
const logger = require("../../logger");
const utils = require("../../utils");

// Delete User with the specified userId in the request
module.exports = exports = {
  // route handler
  handler: async (req, res) => {
    let { user } = req;
    const { id } = req.params;

    if (!id) {
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.INVALID_PARAMETERS,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.BAD_REQUEST)
        .json(utils.createResponseObject(data4createResponseObject));
    }

    let criteria = {
        _id : id
    }

    if ( user.role !== enums.USER_TYPE.ADMIN && user.role !== enums.USER_TYPE.HR ) {
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.NOT_ALLOWED,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.METHOD_NOT_ALLOWED)
          .json(utils.createResponseObject(data4createResponseObject));
      }
    else
    {
        try {
            let findClient = await global.models.GLOBAL.CLIENT.findOne(criteria);
      
            if (!findClient) {
              let data4createResponseObject = {
                req: req,
                result: -1,
                message: messages.CLIENT_DOES_NOT_EXIST,
                payload: {},
                logPayload: false,
              };
              return res
                .status(enums.HTTP_CODES.NOT_FOUND)
                .json(utils.createResponseObject(data4createResponseObject));
            } else {

                let updateClientPayload = {
                    clientName : req.body.clientName,
                    updateAt : new Date()
                }

              let updateClient = await global.models.GLOBAL.CLIENT.findOneAndUpdate(criteria , updateClientPayload);
              if (!updateClient) {
                let data4createResponseObject = {
                  req: req,
                  result: -1,
                  message: messages.CLIENT_UPDATE_FAILED,
                  payload: {},
                  logPayload: false,
                };
                return res
                  .status(enums.HTTP_CODES.BAD_REQUEST)
                  .json(utils.createResponseObject(data4createResponseObject));
              } else {
                let data4createResponseObject = {
                  req: req,
                  result: 0,
                  message: messages.CLIENT_UPDATE_SUCCESS,
                  payload: {},
                  logPayload: false,
                };
                return res
                  .status(enums.HTTP_CODES.OK)
                  .json(utils.createResponseObject(data4createResponseObject));
              }
            }
          } catch (error) {
            logger.error(
              `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
            );
            let data4createResponseObject = {
              req: req,
              result: -1,
              message: messages.GENERAL,
              payload: {},
              logPayload: false,
            };
            res
              .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
              .json(utils.createResponseObject(data4createResponseObject));
          }
    }



  },
};
