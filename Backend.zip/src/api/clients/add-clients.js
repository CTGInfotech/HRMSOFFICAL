const Joi = require("joi");
const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");
const logger = require("../../logger");
const utils = require("../../utils");

// User Registration
module.exports = exports = {
 
  // route handler
  handler: async (req, res) => {

    const { user } = req

    console.log("client req" , req.body)

    if ( user.role !== enums.USER_TYPE.ADMIN && user.role !== enums.USER_TYPE.HR ) {
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.NOT_ALLOWED,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.METHOD_NOT_ALLOWED)
          .json(utils.createResponseObject(data4createResponseObject));
    }

    const {
      clientId ,
      clientName
    } = req.body;

    if (
        !clientName
    ) {
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.INVALID_PARAMETERS,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.BAD_REQUEST)
        .json(utils.createResponseObject(data4createResponseObject));
    }

    try {

      let findAllUser = await global.models.GLOBAL.CLIENT.find();

      let clientId = 'C0001'

      if(findAllUser.length > 0)
      {
        let newClient = findAllUser[findAllUser.length-1].clientId
        console.log(newClient )
        console.log(newClient.slice(1,))
        clientId = `${10000 + parseInt(newClient.slice(1,)) + 1}`
        clientId = 'C' + clientId.slice(1,)
      }

      console.log("check " , clientId)
      let findUser = await global.models.GLOBAL.CLIENT.find({
          clientId : clientId
      });

      console.log(findUser)
      if (findUser.length > 0) {
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.CLIENT_ALREADY_EXIST,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.DUPLICATE_VALUE)
          .json(utils.createResponseObject(data4createResponseObject));
      } else {
        let clientDetailsAdd = {
            clientId : clientId ,
            clientName : clientName , 
            createAt : new Date()
        };

        const newClient = await global.models.GLOBAL.CLIENT.create(
            clientDetailsAdd
        );
        if (!newClient) {
          let data4createResponseObject = {
            req: req,
            result: -1,
            message: messages.CLIENT_ADD_FAILED,
            payload: {},
            logPayload: false,
          };
          return res
            .status(enums.HTTP_CODES.BAD_REQUEST)
            .json(utils.createResponseObject(data4createResponseObject));
        } else {
          let data4createResponseObject = {
            req: req,
            result: 0,
            message: messages.CLIENT_ADD_SUCCESS,
            payload: newClient,
            logPayload: false,
          };
          return res
            .status(enums.HTTP_CODES.OK)
            .json(utils.createResponseObject(data4createResponseObject));
        }
      }
    } catch (error) {
      logger.error(
        `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
      );
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.GENERAL,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
        .json(utils.createResponseObject(data4createResponseObject));
    }
  },
};
