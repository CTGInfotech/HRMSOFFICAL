const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");

const logger = require("../../logger");
const utils = require("../../utils");

// Holiday update
module.exports = exports = {
  // route handler
  handler: async (req, res) => {
    const { user } = req;
    const { id } = req.params;
    try {
      if (
        user.role !== enums.USER_TYPE.ADMIN &&
        user.role !== enums.USER_TYPE.HR
      ) {
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.NOT_ALLOWED,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.METHOD_NOT_ALLOWED)
          .json(utils.createResponseObject(data4createResponseObject));
      }

      let findHoliday = await global.models.GLOBAL.HOLIDAYS.findOne({
        _id: id,
      });
      if (!findHoliday) {
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.HOLIDAY_NOT_FOUND,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.NOT_FOUND)
          .json(utils.createResponseObject(data4createResponseObject));
      } else {
        let body = {
          ...req.body,
          updatedBy: user._id,
          updatedAt: new Date(),
        };
        let updateHoliday =
          await global.models.GLOBAL.HOLIDAYS.findByIdAndUpdate(
            findHoliday._id,
            body
          );
        if (!updateHoliday) {
          let data4createResponseObject = {
            req: req,
            result: -1,
            message: messages.HOLIDAY_UPDATE_FAILED,
            payload: {},
            logPayload: false,
          };
          return res
            .status(enums.HTTP_CODES.BAD_REQUEST)
            .json(utils.createResponseObject(data4createResponseObject));
        } else {
          updateHoliday = await global.models.GLOBAL.HOLIDAYS.findOne({
            _id: id,
          });
          let data4createResponseObject = {
            req: req,
            result: 0,
            message: messages.HOLIDAY_UPDATED,
            payload: { updateHoliday: updateHoliday },
            logPayload: false,
          };
          return res
            .status(enums.HTTP_CODES.OK)
            .json(utils.createResponseObject(data4createResponseObject));
        }
      }
    } catch (error) {
      logger.error(
        `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
      );
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.GENERAL,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
        .json(utils.createResponseObject(data4createResponseObject));
    }
  },
};
