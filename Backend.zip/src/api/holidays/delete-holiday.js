const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");
const logger = require("../../logger");
const utils = require("../../utils");

// Delete Holiday with the specified holidayId in the request
module.exports = exports = {
  // route handler
  handler: async (req, res) => {
    let { user } = req;
    const { id } = req.params;

    if (!id) {
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.INVALID_PARAMETERS,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.BAD_REQUEST)
        .json(utils.createResponseObject(data4createResponseObject));
    }
    try {
      if (
        user.role !== enums.USER_TYPE.ADMIN &&
        user.role !== enums.USER_TYPE.HR
      ) {
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.NOT_ALLOWED,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.METHOD_NOT_ALLOWED)
          .json(utils.createResponseObject(data4createResponseObject));
      }

      let findHoliday = await global.models.GLOBAL.HOLIDAYS.findOne({
        _id: id,
      });

      if (!findHoliday) {
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.HOLIDAY_NOT_FOUND,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.NOT_FOUND)
          .json(utils.createResponseObject(data4createResponseObject));
      } else {
        let deleteHoliday =
          await global.models.GLOBAL.HOLIDAYS.findByIdAndRemove({
            _id: id,
          });
        if (!deleteHoliday) {
          let data4createResponseObject = {
            req: req,
            result: -1,
            message: messages.HOLIDAY_DELETE_FAILED,
            payload: {},
            logPayload: false,
          };
          return res
            .status(enums.HTTP_CODES.BAD_REQUEST)
            .json(utils.createResponseObject(data4createResponseObject));
        } else {
          let data4createResponseObject = {
            req: req,
            result: 0,
            message: messages.HOLIDAY_DELETED,
            payload: {},
            logPayload: false,
          };
          return res
            .status(enums.HTTP_CODES.OK)
            .json(utils.createResponseObject(data4createResponseObject));
        }
      }
    } catch (error) {
      logger.error(
        `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
      );
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.GENERAL,
        payload: {},
        logPayload: false,
      };
      res
        .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
        .json(utils.createResponseObject(data4createResponseObject));
    }
  },
};
