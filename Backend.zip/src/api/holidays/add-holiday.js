const Joi = require("joi");
const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");
const logger = require("../../logger");
const utils = require("../../utils");

// Holiday Create
module.exports = exports = {
  // route validation
  validation: Joi.object({
    name: Joi.string().required(),
    description: Joi.string().required(),
    startDate: Joi.date().required(),
    endDate: Joi.date().required(),
    year: Joi.number().required(),
    calenderColor: Joi.string().required(),
    country: Joi.string().required()
  }),

  // route handler
  handler: async (req, res) => {
    const { user } = req;
    const { name, description, startDate, endDate, year, calenderColor,country } =
      req.body;
    const isActive = req.body.isActive || true;

    if (
      !name ||
      !description ||
      !startDate ||
      !endDate ||
      !year ||
      !calenderColor || !country
    ) {
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.INVALID_PARAMETERS,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.BAD_REQUEST)
        .json(utils.createResponseObject(data4createResponseObject));
    }

    try {
      let holidayData = {
        name: name,
        description: description,
        startDate: startDate,
        endDate: endDate,
        isActive: isActive,
        year: year,
        calenderColor: calenderColor,
        country: country,
        createdBy: user._id,
        createdAt: new Date(),
      };
      if (
        user.role !== enums.USER_TYPE.ADMIN &&
        user.role !== enums.USER_TYPE.HR
      ) {
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.NOT_ALLOWED,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.METHOD_NOT_ALLOWED)
          .json(utils.createResponseObject(data4createResponseObject));
      }

      const newHoliday = await global.models.GLOBAL.HOLIDAYS.create(
        holidayData
      );
      if (!newHoliday) {
        let data4createResponseObject = {
          req: req,
          result: 0,
          message: messages.HOLIDAY_CREATED_FAILED,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.BAD_REQUEST)
          .json(utils.createResponseObject(data4createResponseObject));
      } else {
        let data4createResponseObject = {
          req: req,
          result: 1,
          message: messages.HOLIDAY_CREATED,
          payload: newHoliday,
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.OK)
          .json(utils.createResponseObject(data4createResponseObject));
      }
    } catch (error) {
      logger.error(
        `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
      );
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.GENERAL,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
        .json(utils.createResponseObject(data4createResponseObject));
    }
  },
};
