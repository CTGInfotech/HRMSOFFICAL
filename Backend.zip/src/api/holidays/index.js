const addHoliday = require("./add-holiday");
const getAllHoliday = require("./get-all-holidays");
const updateHoliday = require("./update-holiday");
const deleteHoliday = require("./delete-holiday");

module.exports = exports = {
  addHoliday,
  getAllHoliday,
  updateHoliday,
  deleteHoliday,
};
