const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");

const logger = require("../../logger");
const utils = require("../../utils");

// Get Holidays
module.exports = exports = {
  handler: async (req, res) => {
    try {
      let {user}= req;
      let year = new Date().getFullYear();
      let assignedCountry = user.assignedCountry ? user.assignedCountry : 'India';
      let findHolidays;
      if(user.role !== enums.USER_TYPE.ADMIN){
        findHolidays =  await global.models.GLOBAL.HOLIDAYS.find({
          year: year,
          country: assignedCountry
        }).sort({ startDate: -1 });
      }else{
        findHolidays =  await global.models.GLOBAL.HOLIDAYS.find({
          year: year
        }).sort({ startDate: -1 });
      }
      

      if (!findHolidays) {
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.HOLIDAY_NOT_FOUND,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.NOT_FOUND)
          .json(utils.createResponseObject(data4createResponseObject));
      } else {
        findHolidays = JSON.parse(JSON.stringify(findHolidays));
        let data4createResponseObject = {
          req: req,
          result: 0,
          message: messages.HOLIDAY_FETCHED,
          payload: { findHolidays },
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.OK)
          .json(utils.createResponseObject(data4createResponseObject));
      }
    } catch (error) {
      logger.error(
        `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
      );
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.GENERAL,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
        .json(utils.createResponseObject(data4createResponseObject));
    }
  },
};
