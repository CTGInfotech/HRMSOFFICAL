const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");
const logger = require("../../logger");
const utils = require("../../utils");
const nodemailer = require("nodemailer");

// Delete User with the specified userId in the request
module.exports = exports = {
  // route handler
  handler: async (req, res) => {
    let { user } = req;
    const { user_id } = req.params;
    console.log(user_id + "Here we are");

    console.log(req.params)

    if (!user_id) {
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.INVALID_PARAMETERS,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.BAD_REQUEST)
        .json(utils.createResponseObject(data4createResponseObject));
    }

    let criteria = {
        _id : user_id
    }

    if ( user.role !== enums.USER_TYPE.ADMIN ) {
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.NOT_ALLOWED,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.METHOD_NOT_ALLOWED)
          .json(utils.createResponseObject(data4createResponseObject));
      }
    else
    {
        try {
            let findUser = await global.models.GLOBAL.ONBOARDING_EMPLOYEE.findOne(criteria);
      
            if (!findUser) {
              let data4createResponseObject = {
                req: req,
                result: -1,
                message: messages.ONBOARDING_EMPLOYEE_DOES_NOT_EXIST,
                payload: {},
                logPayload: false,
              };
              return res
                .status(enums.HTTP_CODES.NOT_FOUND)
                .json(utils.createResponseObject(data4createResponseObject));
            } else {

              let checkUser = await global.models.GLOBAL.USER.find({
                $or: [{ email: findUser.email }],
              });

              console.log(checkUser , "check")

              if (checkUser.length > 0) {
                let data4createResponseObject = {
                  req: req,
                  result: -1,
                  message: messages.ONBOARDING_EMPLOYEE_ALREADY_EXIST,
                  payload: {},
                  logPayload: false,
                };
                return res
                  .status(enums.HTTP_CODES.DUPLICATE_VALUE)
                  .json(utils.createResponseObject(data4createResponseObject));
              }
              else
              {
              
                var autoPassword =  utils.generatePassword()
                var autoHashPassword = utils.passwordHash(autoPassword)
                var autoUserId = Math.floor(Math.random() * 100000000)


                let userRegistrationData = {
                    firstName: findUser?.firstName,
                    lastName: findUser?.lastName,
                    email: findUser?.email,
                    dob: findUser?.dob,
                    nationality: findUser?.nationality,
                    phone: findUser?.phone1,
                    address: findUser?.address,
                    gender: findUser?.gender,
                    createdAt: Date.now(),
                    fatherName: findUser?.fatherName,
                    motherName: findUser?.motherName,
                    password : autoHashPassword,
                    userId : autoUserId,
                    bloodGroup: findUser?.bloodGroup,
                    employeePhoto : findUser?.employeePhoto,
                    adharcardNo : findUser?.adharcardNo,
                    pancardNo   : findUser?.pancardNo ,

                    previousEmployeeDetails : {
                      prevEmploymentType : findUser?.previousEmployeeDetails?.prevEmploymentType ,
                      prevOfficeBranch : findUser?.previousEmployeeDetails?.prevOfficeBranch,
                      prevOfficeAddress : findUser?.previousEmployeeDetails?.prevOfficeAddress ,
                      prevOfficeContactNo : findUser?.previousEmployeeDetails?.prevOfficeContactNo ,
                      prevOfficeEmailId : findUser?.previousEmployeeDetails?.prevOfficeEmailId ,
                      prevDesignation : findUser?.previousEmployeeDetails?.prevDesignation , 
                      prevPFAccountNo:  findUser?.previousEmployeeDetails?.prevPFAccountNo  ,
                      prevUANNo  : findUser?.previousEmployeeDetails?.prevUANNo ,
                      prevESINo : findUser?.previousEmployeeDetails?.prevESINo ,
                      leavingDate :findUser?.previousEmployeeDetails?.leavingDate , 
                      prevAnnualSalary : findUser?.previousEmployeeDetails?.prevAnnualSalary,
                      payslips : findUser?.previousEmployeeDetails?.payslips,
                      resignationForm : findUser?.previousEmployeeDetails?.resignationForm
                    },
                    bankinformation: {
                      bankAccountNo: findUser?.bankinformation?.bankAccountNo ,
                      bankName: findUser?.bankinformation?.bankName,
                      bankBranch: findUser?.bankinformation?.bankBranch,
                      ifscCode: findUser?.bankinformation?.ifscCode,
                    },
                
                    emergencyContact: {
          
                      emergencyContactEmail: findUser?.emergencyContact?.emergencyContactEmail,
                      emergencyContactName1: findUser?.emergencyContact?.emergencyContactName1,
                      emergencyContactRalationship1: findUser?.emergencyContact?.emergencyContactRalationship1,
                      emergencyContactPhon1: findUser?.emergencyContact?.emergencyContactPhon1,
                      emergencyContactName2: findUser?.emergencyContact?.emergencyContactName2,
                      emergencyContactRalationship2: findUser?.emergencyContact?.emergencyContactRalationship2,
                      emergencyContactPhon2: findUser?.emergencyContact?.emergencyContactPhon2,
                    },
                  };

                  console.log("user data" , userRegistrationData)

                 const newUser = await global.models.GLOBAL.USER.create(
                    userRegistrationData
                  );

                console.log(newUser , "asdfg")
                console.log("Auto Password" , autoPassword);
                  if (!newUser) {
                    let data4createResponseObject = {
                      req: req,
                      result: -1,
                      message: messages.ONBOARDING_EMPLOYEE_APPROVED_FAILED,
                      payload: {},
                      logPayload: false,
                    };
                    return res
                      .status(enums.HTTP_CODES.BAD_REQUEST)
                      .json(utils.createResponseObject(data4createResponseObject));
                  } else {

                    console.log("MAIL SENDING");
                    let transporter = nodemailer.createTransport({
                      // service: "gmail",
                      host: process.env.SMTP_HOST,
                      port: process.env.SMTP_POST,
                      secure: false,
                      auth: {
                        user: process.env.SMTP_USERNAME,
                        pass: process.env.SMTP_PASSWORD,
                      },
                      tls: {
                        rejectUnauthorized: false
                      }
                    });
                    let info = await transporter.sendMail({
                      from: process.env.SMTP_FROM_EMAIL,
                      to: newUser.email,
                      subject: "CTG HRMS | Approved your Onboarding process",
                      text:
                        "Your Onboarding process is completed and approved by admin\n\n" +
                        "Your new Employee Id and Password is generated and given it below.Use it for login the portal\n\n" +
                        `Employee Id : ${autoUserId}\n\n` +
                        `Temporary Password : ${autoPassword}\n\n` +
                        "If you did not request this, please ignore this email\n",
                    });

                 console.log(info)

                    let deleteUser = await global.models.GLOBAL.ONBOARDING_EMPLOYEE.findByIdAndRemove(criteria);
                    if (!deleteUser) {
                      let data4createResponseObject = {
                        req: req,
                        result: -1,
                        message: messages.ONBOARDING_EMPLOYEE_APPROVED,
                        payload: {},
                        logPayload: false,
                      };
                      return res
                        .status(enums.HTTP_CODES.BAD_REQUEST)
                        .json(utils.createResponseObject(data4createResponseObject));
                    } else {
                      let data4createResponseObject = {
                        req: req,
                        result: 0,
                        message: messages.ONBOARDING_EMPLOYEE_APPROVED,
                        payload: {},
                        logPayload: false,
                      };
                      return res
                        .status(enums.HTTP_CODES.OK)
                        .json(utils.createResponseObject(data4createResponseObject));
                    }


                  }
                }
            }
          } catch (error) {
            logger.error(
              `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
            );
            let data4createResponseObject = {
              req: req,
              result: -1,
              message: messages.GENERAL,
              payload: {},
              logPayload: false,
            };
            res
              .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
              .json(utils.createResponseObject(data4createResponseObject));
          }
    }



  },
};
