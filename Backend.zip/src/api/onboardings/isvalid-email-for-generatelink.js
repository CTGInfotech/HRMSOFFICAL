const enums = require("../../../json/enums.json");
const messages = require("../../../json/messages.json");

const logger = require("../../logger");
const utils = require("../../utils");

// Get User by ID
module.exports = exports = {
  handler: async (req, res) => {
    const { user } = req;
    try {
      let { email } = req.params;

      if (!email) {
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.INVALID_PARAMETERS,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.BAD_REQUEST)
          .json(utils.createResponseObject(data4createResponseObject));
      }

      let criteria;
      if (email) {
        criteria = {
          email: email,
        };
      }

      if ( user.role !== enums.USER_TYPE.ADMIN ) {
        let data4createResponseObject = {
          req: req,
          result: -1,
          message: messages.NOT_ALLOWED,
          payload: {},
          logPayload: false,
        };
        return res
          .status(enums.HTTP_CODES.METHOD_NOT_ALLOWED)
          .json(utils.createResponseObject(data4createResponseObject));
      } else {
        let findOnboardingEmployee = await global.models.GLOBAL.ONBOARDING_EMPLOYEE.findOne(criteria)
        let findUserEmployee = await global.models.GLOBAL.USER.findOne(criteria)

        console.log(findOnboardingEmployee , findUserEmployee)

        let data4createResponseObject = {
            req: req,
            result: 0,
            message: messages.ONBOARDING_FETCH_SUCCESS,
            payload: true,
            logPayload: false,
        };

        if(!findOnboardingEmployee && !findUserEmployee)
        {
            data4createResponseObject.payload = false
        }
        return res
            .status(enums.HTTP_CODES.OK)
            .json(utils.createResponseObject(data4createResponseObject));
      }
    } catch (error) {
      logger.error(
        `${req.originalUrl} - Error encountered: ${error.message}\n${error.stack}`
      );
      let data4createResponseObject = {
        req: req,
        result: -1,
        message: messages.GENERAL,
        payload: {},
        logPayload: false,
      };
      return res
        .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
        .json(utils.createResponseObject(data4createResponseObject));
    }
  },
};
