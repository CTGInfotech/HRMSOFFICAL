
const addOnboardingEmployee = require("./add-employee")
const getOnboardingEmployeeByEmail = require("./get-employee-by-email")
const getOnboardingAllEmployee = require("./get-all-employee.js")
const isValidEmailForGenerateLink = require("./isvalid-email-for-generatelink")
const rejectOnboardingEmployeeById = require("./reject-employee")
const approveOnboardingEmployeeById = require("./approve-employee")

module.exports = exports = {
    addOnboardingEmployee,
    getOnboardingEmployeeByEmail,
    getOnboardingAllEmployee,
    isValidEmailForGenerateLink,
    rejectOnboardingEmployeeById,
    approveOnboardingEmployeeById
};
