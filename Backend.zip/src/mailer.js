const nodemailer=require('nodemailer');
require('dotenv').config();


 let transporter = nodemailer.createTransport({
    // service: "gmail",
    host: process.env.SMTP_HOST,
    port: process.env.SMTP_POST,
    secure: false,
    auth: {
      user: process.env.SMTP_USERNAME,
      pass: process.env.SMTP_PASSWORD,
    },
    tls: {
      rejectUnauthorized: false
    }
});

const sendApprovedTimesheetMail=async (email,month)=>{
  let info = await transporter.sendMail({
    from: process.env.SMTP_FROM_EMAIL,
    to: email,
    subject: "CTG HRMS | Timesheet Approved",
    text: `Your Timesheet has been Approved for month ${month}`,
  });
  console.log("Message sent: %s", info.messageId);
}

const sendRejectedTimesheetMail=async (email,month)=>{
  let info = await transporter.sendMail({
    from: process.env.SMTP_FROM_EMAIL,
    to: email,
    subject: "CTG HRMS | Timesheet Rejected",
    text:  `Your Timesheet has been Rejected for month ${month}`,
  });
  console.log("Message sent: %s", info.messageId);
}

const sendTimesheetWeeklyRemainder=async (email)=>{
  const monthNames = ["January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];
  const d = new Date();
  let info = await transporter.sendMail({
    from: process.env.SMTP_FROM_EMAIL,
    to: email,
    subject: "CTG HRMS | Timesheet Reminder",
    text:  `This is reminder to fill/update the timesheet of ${monthNames[d.getMonth()]}. Ignore if already done.`,
  });
  console.log("Message sent: %s", info.messageId);

}

module.exports={
    sendApprovedTimesheetMail,
    sendRejectedTimesheetMail,
    sendTimesheetWeeklyRemainder
}