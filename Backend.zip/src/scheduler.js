const {schedule}=require('node-cron')
const {sendTimesheetWeeklyRemainder}=require("./mailer")

const startScheduler=async ()=>{
    try{
        console.log("scheduler started")
        const task=schedule('00 11 * * Sun',async ()=>{
            try{
            let findUsers = await global.models.GLOBAL.USER.find({});
            for(let i=0; i<findUsers.length; i+=1){
                const user = findUsers[i];
                await sendTimesheetWeeklyRemainder(user.email);
            }
            
        }catch(e){
            console.log(e);
        }            
        })
        task.start();
    }catch(error){
       console.log(error);
    }
}

module.exports=startScheduler;