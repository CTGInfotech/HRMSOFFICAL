const mongoose = require("mongoose");
const logger = require("../logger");
const ConnectionFactory = require("./connection-factory");
const config = require("../../config.json");

module.exports = async () => {
  mongoose.pluralize(null); // So that mongoose doesn't try to pluralize the schema and map accordingly.
  let models;
  try {
    const connectionFactory = new ConnectionFactory(config);
    // GLOBAL Connections
    const connection_IN_HRMS = await connectionFactory.getConnection(
      "GLOBAL",
      config.MONGODB.GLOBAL.DATABASE.HRMS
    );

    const mongooseConnections = {
      GLOBAL: {
        HRMS: connection_IN_HRMS,
      },
    };

    /* All the (mongoose) models to be defined here */
    models = {
      GLOBAL: {
        LOG: require("../schema/log/log")(mongooseConnections.GLOBAL.HRMS),
        USER: require("../schema/user/user")(mongooseConnections.GLOBAL.HRMS),
        EVENTS: require("../schema/events/events")(
          mongooseConnections.GLOBAL.HRMS
        ),
        HOLIDAYS: require("../schema/holidays/holidays")(
          mongooseConnections.GLOBAL.HRMS
        ),
        LEAVES: require("../schema/leaves/leaves")(
          mongooseConnections.GLOBAL.HRMS
        ),
        PAYMENT_TO_EMPLOYEE:
          require("../schema/paymentToEmployee/paymentToEmployee")(
            mongooseConnections.GLOBAL.HRMS
          ),
        PREVIOUS_WORK_INFO:
          require("../schema/previousWorkInformation/previousWorkInformation")(
            mongooseConnections.GLOBAL.HRMS
          ),
        ONBOARDING_EMPLOYEE:
          require("../schema/onboarding_employees/onboardingEmployee")(
            mongooseConnections.GLOBAL.HRMS
          ),
        TIMESHEET_FILL:
          require("../schema/timesheets/timesheetFill")(
            mongooseConnections.GLOBAL.HRMS
          ),
        CLIENT : 
            require("../schema/clients/clients")(
              mongooseConnections.GLOBAL.HRMS
          ),
        PROJECT :
            require("../schema/projects/project")(
              mongooseConnections.GLOBAL.HRMS
            )
      },
    };

    return models;
  } catch (error) {
    logger.error(
      "Error encountered while trying to create database connections and models:\n" +
        error.stack
    );
    return null;
  }
};
