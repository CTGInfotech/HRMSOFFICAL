const express = require("express");
const router = express.Router();
const api4Holiday = require("../../api/holidays/index");
const { validate } = require("../../middlewares");
const passport = require("passport");

// Post Methods
router.post(
  "/add",
  passport.authenticate("jwt", { session: false }),
  validate("body", api4Holiday.addHoliday.validation),
  api4Holiday.addHoliday.handler
);

// Put Method
router.put(
  "/id=:id",
  passport.authenticate(["jwt"], { session: false }),
  api4Holiday.updateHoliday.handler
);

// Get Method
router.get(
  "/",
  passport.authenticate(["jwt"], { session: false }),
  api4Holiday.getAllHoliday.handler
);

// Delete Method (Put Method)
router.put(
  "/delete/id=:id",
  passport.authenticate(["jwt"], { session: false }),
  api4Holiday.deleteHoliday.handler
);

module.exports = exports = router;
