const express = require("express");
const router = express.Router();
const api4Project = require("../../api/projects/index");
const { validate } = require("../../middlewares");
const passport = require("passport");

router.post("/addProject" , passport.authenticate(["jwt"], { session: false })  , api4Project.addProject.handler )
router.get("/getAllProjects" , api4Project.getAllProject.handler )
router.put("/updateProjectById/:id" , passport.authenticate(["jwt"], { session: false })  , api4Project.updateProejctById.handler )
router.delete("/deleteProjectById/:id" , passport.authenticate(["jwt"], { session: false })  , api4Project.deleteProjectById.handler )
router.get("/getAllProjectsByClientId/:clientId" ,api4Project.getAllProjectByClientId.handler  )
router.get("/getMyProjectsByClientId/:clientId", passport.authenticate(["jwt"], { session: false }) ,api4Project.getMyProjectByClientId.handler  )

module.exports = exports = router;
