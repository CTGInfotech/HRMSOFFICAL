const express = require("express");
const router = express.Router();
const api4PaySlip = require("../../api/paySLip/index");
const { validate } = require("../../middlewares");
const passport = require("passport");
const { paySlipUploadS3 } = require("../../utils");

// Post Methods
router.post(
  "/add/id=:id",
  passport.authenticate("jwt", { session: false }),
  paySlipUploadS3,
  api4PaySlip.addPaySlip.handler
);

// Post Methods
router.post(
  "/bulk-add",
  passport.authenticate("jwt", { session: false }),
  paySlipUploadS3,
  api4PaySlip.addPaySlip.bulkHandler
);

// Get Method
router.get(
  "/",
  passport.authenticate(["jwt"], { session: false }),
  api4PaySlip.getPaySlip.handler
);

//Delete Method
router.delete(
  "/id=:id",
  passport.authenticate(["jwt"], { session: false }),
  api4PaySlip.deletePaySlip.handler
);

module.exports = exports = router;
