const express = require("express");
const router = express.Router();
const api4Events = require("../../api/events/index");
const { validate } = require("../../middlewares");
const passport = require("passport");

// Post Methods
router.post(
  "/create",
  passport.authenticate("jwt", { session: false }),
  validate("body", api4Events.addEvents.validation),
  api4Events.addEvents.handler
);

// Put Method
router.put(
  "/id=:id",
  passport.authenticate(["jwt"], { session: false }),
  api4Events.updateEvents.handler
);

// Get Method
router.get(
  "/",
  passport.authenticate(["jwt"], { session: false }),
  api4Events.getEvents.handler
);

// Delete Method
router.delete(
  "/id=:id",
  passport.authenticate(["jwt"], { session: false }),
  api4Events.deleteEvents.handler
);

module.exports = exports = router;
