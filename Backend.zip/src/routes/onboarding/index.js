const express = require("express");
const router = express.Router();
const api4User = require("../../api/onboardings/index");
const { validate } = require("../../middlewares");
const passport = require("passport");
const { onboardingFileUploadS3 } = require("../../utils");

// Post Methods
router.post("/addEmployee", onboardingFileUploadS3 ,  api4User.addOnboardingEmployee.handler);
router.get("/getEmployeeByEmail/:email", api4User.getOnboardingEmployeeByEmail.handler )
router.get("/getAllEmployee",passport.authenticate(["jwt"], { session: false }) , api4User.getOnboardingAllEmployee.handler )
router.get("/isValidEmailForGenerateLink/:email",passport.authenticate(["jwt"], { session: false }) , api4User.isValidEmailForGenerateLink.handler )
router.put("/rejectOnboardingEmployeeById/:user_id",passport.authenticate(["jwt"], { session: false }) , api4User.rejectOnboardingEmployeeById.handler )
router.put("/approveOnboardingEmployeeById/:user_id",passport.authenticate(["jwt"], { session: false }) , api4User.approveOnboardingEmployeeById.handler )

module.exports = exports = router;
