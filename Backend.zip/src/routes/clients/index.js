const express = require("express");
const router = express.Router();
const api4Client = require("../../api/clients/index");
const { validate } = require("../../middlewares");
const passport = require("passport");

router.post("/addClient" , passport.authenticate(["jwt"], { session: false })  , api4Client.addClient.handler )
router.get("/getAllClients" , api4Client.getClients.handler )
router.get("/getMyClients", passport.authenticate(["jwt"], { session: false }) , api4Client.myClients.handler )
router.put("/updateClientById/:id" , passport.authenticate(["jwt"], { session: false })  , api4Client.updateClientById.handler )
router.delete("/deleteClientById/:id" , passport.authenticate(["jwt"], { session: false })  , api4Client.deleteClietById.handler )

module.exports = exports = router;
