const express = require("express");
const router = express.Router();
const api4User = require("../../api/user/index");
const { validate } = require("../../middlewares");
const passport = require("passport");
const { editEmployeeFileUploadS3 } = require("../../utils");
const { onboardingFileUploadS3 } = require("../../utils");

// Post Methods
router.post("/registration", api4User.userRegistration.handler);

router.post("/add-employee", onboardingFileUploadS3, api4User.addEmployee.handler);

router.post(
  "/login",
  validate("body", api4User.userLogin.validation),
  api4User.userLogin.handler
);
router.post(
  "/reset",
  passport.authenticate(["jwt"], { session: false }),
  validate("body", api4User.resetPassword.validation),
  api4User.resetPassword.handler
);
router.post(
  "/forgot",
  validate("body", api4User.forgotPassword.validation),
  api4User.forgotPassword.handler
);
router.post(
  "/change/:token",
  validate("body", api4User.changePassword.validation),
  api4User.changePassword.handler
);
router.post(
  "/work-info",
  passport.authenticate(["jwt"], { session: false }),
  validate("body", api4User.previousWorkInfo.validation),
  api4User.previousWorkInfo.handler
);
// Put Method
router.put(
  "/",
  passport.authenticate(["jwt"], { session: false }),
  editEmployeeFileUploadS3,
  api4User.userUpdate.handler
);
router.put(
  "/status/:id",
  passport.authenticate(["jwt"], { session: false }),
  api4User.updateStatus.handler
);
router.put(
  "/logout",
  passport.authenticate(["jwt"], { session: false }),
  api4User.userLogout.handler
);

// Get Method
router.get(
  "/employee",
  passport.authenticate(["jwt"], { session: false }),
  api4User.getEmployee.handler
);
router.get(
  "/admin",
  passport.authenticate(["jwt"], { session: false }),
  api4User.getAdmin.handler
);
router.get(
  "/hr",
  passport.authenticate(["jwt"], { session: false }),
  api4User.getHr.handler
);
router.get(
  "/count",
  passport.authenticate(["jwt"], { session: false }),
  api4User.getCount.handler
);
router.get(
  "/upcoming-birthday",
  passport.authenticate(["jwt"], { session: false }),
  api4User.upCommingBirthday.handler
);
router.get(
  "/search",
  passport.authenticate(["jwt"], { session: false }),
  api4User.searchUser.handler
);

router.get(
  "/Holidays/:month", passport.authenticate(["jwt"], { session: false }),
  api4User.getHolidays.handler
)


// Delete Method
router.delete(
  "/userId=:userId",
  passport.authenticate(["jwt"], { session: false }),
  api4User.deleteUser.handler
);

module.exports = exports = router;
