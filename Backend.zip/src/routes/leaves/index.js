const express = require("express");
const router = express.Router();
const api4Leaves = require("../../api/leaves/index");
const { validate } = require("../../middlewares");
const passport = require("passport");

// Post Methods
router.post(
  "/add",
  passport.authenticate("jwt", { session: false }),
  validate("body", api4Leaves.addLeave.validation),
  api4Leaves.addLeave.handler
);

// Put Method
router.put(
  "/id=:id",
  passport.authenticate(["jwt"], { session: false }),
  api4Leaves.updateLeave.handler
);
router.put(
  "/accept/id=:id",
  passport.authenticate(["jwt"], { session: false }),
  api4Leaves.acceptLeave.handler
);
router.put(
  "/reject/id=:id",
  passport.authenticate(["jwt"], { session: false }),
  api4Leaves.rejectLeave.handler
);

// Get Method
router.get(
  "/",
  passport.authenticate(["jwt"], { session: false }),
  api4Leaves.getLeaveByUser.handler
);

module.exports = exports = router;
