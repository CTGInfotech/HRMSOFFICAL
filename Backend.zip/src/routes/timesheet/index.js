const express = require("express");
const router = express.Router();
const api4Timesheet = require("../../api/timesheets/index");
const { validate } = require("../../middlewares");
const passport = require("passport");

// Post Methods

router.post("/timesheetFilled",passport.authenticate(["jwt"], { session: false }) , api4Timesheet.timesheetFilled.handler);
router.post("/timesheetSaved",passport.authenticate(["jwt"], { session: false }) , api4Timesheet.saveTimesheetDraft.handler);
router.post("/consolidatedReport",passport.authenticate(["jwt"], { session: false }) , api4Timesheet.consolidatedReportPdf.handler);
router.get("/getTimesheetByMonth/:month" , passport.authenticate(["jwt"], { session: false }) , api4Timesheet.getTimesheetByMonth.handler )
router.get("/export/pdf/:timesheetId" , api4Timesheet.exportTimesheetPdf.handler );
router.get("/export/excel/:timesheetId" , api4Timesheet.exportTimesheetExcel.handler );
router.post("/export/consolidatedReport",api4Timesheet.exportConsolidatedReportPdf.handler);
router.post("/export/consolidatedTimesheet",api4Timesheet.exportConsolidatedTimesheetPdf.handler);
router.post("/export/consolidatedReportExcel",api4Timesheet.exportConsolidatedReportExcel.handler);
router.post("/export/consolidatedTimesheetExcel",api4Timesheet.exportConsolidatedTimesheetExcel.handler);
router.get("/getAllTimesheetForApproveByMonth/:month"  , passport.authenticate(["jwt"], { session: false }) , api4Timesheet.getAllTimesheetForApproveByMonth.handler  )
router.get("/isValidDateForFillTimesheet/:month"  , passport.authenticate(["jwt"], { session: false }) , api4Timesheet.isValidDateForFIllTimesheet.handler  )
router.put("/approvedTimesheetById/:user_id"  , passport.authenticate(["jwt"], { session: false }) , api4Timesheet.approvedTimesheetById.handler  )
router.put("/updateTimesheetById/:user_id"  , passport.authenticate(["jwt"], { session: false }) , api4Timesheet.updateTimesheetById.handler  )
router.put("/rejectTimesheetById/:user_id"  , passport.authenticate(["jwt"], { session: false }) , api4Timesheet.rejectTimesheetById.handler  )


module.exports = exports = router;
