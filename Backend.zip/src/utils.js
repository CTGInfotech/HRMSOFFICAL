const _ = require("lodash");
const accepts = require("accepts");
const crypto = require("crypto");
const flatten = require("flat");
const logger = require("./logger");
const { default: jwtDecode } = require("jwt-decode");
const multer = require("multer");
const multerS3 = require("multer-s3");
var AWS = require("aws-sdk");
const messages = require("../json/messages.json")
const enums = require("../json/enums.json")

const { s3Config } = require("./middlewares/config");
AWS.config.update({
  accessKeyId: s3Config.clientId,
  secretAccessKey: s3Config.clientSecret,
  region: s3Config.region,
});

const s3 = new AWS.S3();

s3.u

let functions = {};

functions.config4hashes = {
  // size of the generated hash
  hashBytes: 32,
  // larger salt means hashed passwords are more resistant to rainbow table, but
  // you get diminishing returns pretty fast
  saltBytes: 16,
  // more iterations means an attacker has to take longer to brute force an
  // individual password, so larger is better. however, larger also means longer
  // to hash the password. tune so that hashing the password takes about a
  // second
  iterations: 872791,
};

/* create response-wrapper object */
functions.createResponseObject = ({
  req,
  result = 0,
  message = "",
  payload = {},
  logPayload = false,
}) => {
  let payload2log = {};
  if (logPayload) {
    payload2log = flatten({ ...payload });
  }

  let messageToLog = `RES [${req.requestId}] [${req.method}] ${req.originalUrl}`;
  messageToLog +=
    (!_.isEmpty(message) ? `\n${message}` : "") +
    (!_.isEmpty(payload) && logPayload
      ? `\npayload: ${JSON.stringify(payload2log, null, 4)}`
      : "");

  if (result < 0 && (result !== -50 || result !== -51)) {
    logger.error(messageToLog);
  } else if (!_.isEmpty(messageToLog)) {
    logger.info(messageToLog);
  }

  return { result: result, message: message, payload: payload };
};

/* Return true if the app is in production mode */
functions.isLocal = () => process.env.APP_ENVIRONMENT.toLowerCase() === "local";

/* Return true if the app is in production mode */
functions.isProduction = () =>
  process.env.APP_ENVIRONMENT.toLowerCase() === "production" ||
  process.env.APP_ENVIRONMENT.toLowerCase() === "prod";

/* Return true if the app is in production mode */
functions.isTest = () => process.env.APP_ENVIRONMENT.toLowerCase() === "test";

/* Mask a name to initials - e.g., change Bhargav Butani to A. B. */

functions.passwordHash = (password) =>
  crypto.createHash("sha256").update(password.toString()).digest("hex");

functions.generatePassword = ()=>{
    var length = 8,
        charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789",
        retVal = "";
    for (var i = 0, n = charset.length; i < length; ++i) {
        retVal += charset.charAt(Math.floor(Math.random() * n));
    }
    return retVal;
}

/** Sort a JSON by keys */
functions.sortByKeys = (obj) => {
  if (_.isEmpty(obj)) {
    return obj;
  }

  const sortedObj = {};
  Object.keys(obj)
    .sort()
    .forEach((key) => {
      sortedObj[key] = obj[key];
    });

  return sortedObj;
};
/* This has to be the last line - add all functions above. */
functions.getHeaderFromToken = async (token) => {
  const decodedToken = jwtDecode(token, {
    complete: true,
  });

  if (!decodedToken) {
    return null;
  }

  return decodedToken;
};


functions.editEmployeeFileUploadS3 = async (req, res, next) => {
  console.log(req.files)

  if(!req.files)
  {
    next()
  }

  const { pancard , passportPhoto , resignationForm , adharno , payslips } = req.files

  

    await new Promise( async (pResolve, pReject) => {
    
      let fileLocation = {}

      var filesUpload = []

      if(pancard)
      {
        const pancardParams = {
          Bucket: s3Config.bucket,
          ACL : 'public-read',
          Key: `service/${req.body.email}-pancard-ser-${
            pancard.name.split(".")[
              pancard.name.split(".").length - 2
            ]
          }.${
            pancard.name.split(".")[
              pancard.name.split(".").length - 1
            ]
          }`,
          Body: pancard.data,
        };

        let pancardUpload = s3.upload(pancardParams).promise()
        filesUpload.push(pancardUpload)
      }

      if (adharno)
      {
        const adharnoParams = {
          Bucket: s3Config.bucket,
          ACL : 'public-read',
          Key: `service/${req.body.email}-adharno-ser-${
            adharno.name.split(".")[
              adharno.name.split(".").length - 2
            ]
          }.${
            adharno.name.split(".")[
              adharno.name.split(".").length - 1
            ]
          }`,
          Body: adharno.data,
        };
        let adharnoUpload = s3.upload(adharnoParams).promise()
        filesUpload.push(adharnoUpload)
      }

      if(passportPhoto)
      {
        const passportPhotoParams = {
          Bucket: s3Config.bucket,
          ACL : 'public-read',
          Key: `service/${req.body.email}-passportPhoto-ser-${
            passportPhoto.name.split(".")[
              passportPhoto.name.split(".").length - 2
            ]
          }.${
            passportPhoto.name.split(".")[
              passportPhoto.name.split(".").length - 1
            ]
          }`,
          Body: passportPhoto.data,
        };
        let passportPhotoUpload = s3.upload(passportPhotoParams).promise()
        filesUpload.push(passportPhotoUpload)
      }
  
      let resignationFormParams = null
      let payslipsParams = null
  
      if(resignationForm)
      {
        resignationFormParams = {
          Bucket: s3Config.bucket,
          ACL : 'public-read',
          Key: `service/${req.body.email}-resginform-ser-${
            resignationForm.name.split(".")[
              resignationForm.name.split(".").length - 2
            ]
          }.${
            resignationForm.name.split(".")[
              resignationForm.name.split(".").length - 1
            ]
          }`,
          Body: resignationForm.data,
        };
        filesUpload.push(s3.upload(resignationFormParams).promise())
      }
  
      if(payslips)
      {
        payslipsParams = {
          Bucket: s3Config.bucket,
          ACL : 'public-read',
          Key: `service/${req.body.email}-payslips-ser-${
            payslips.name.split(".")[
              payslips.name.split(".").length - 2
            ]
          }.${
            payslips.name.split(".")[
              payslips.name.split(".").length - 1
            ]
          }`,
          Body: payslips.data,
        };
  
        filesUpload.push(s3.upload(payslipsParams).promise())
      }
  
      Promise.all(filesUpload).then(function(data){

        req.body.pancard = data.length >= 1 ? data[0].Location : req.body.pancard 
        req.body.adharno = data.length >= 2  ? data[1].Location : req.body.adharno
        req.body.passportPhoto = data.length >= 3 ? data[2].Location : req.body.passportPhoto
        req.body.resignationForm = data.length >= 4 ? data[3].Location : req.body.resignationForm
        req.body.payslips = data.length >=5 ? data[4].Location : req.body.payslips

        console.log("data" , data)
  
        pResolve(data)
        }).catch(function(err){
          throw err;
        }) 
  
    }).then((resolve) => {
      next();
    });
};


functions.onboardingFileUploadS3 = async (req, res, next) => {

  const { pancard , passportPhoto , resignationForm , adharno , payslipMonth1, payslipMonth2, payslipMonth3 } = req.files

    console.log(req.files , "check again@")

    await new Promise( async (pResolve, pReject) => {
    
      let fileLocation = {}
  
      const pancardParams = {
        Bucket: s3Config.bucket,
        ACL : 'public-read',
        Key: `service/${req.body.email}-pancard-ser-${
          pancard.name.split(".")[
            pancard.name.split(".").length - 2
          ]
        }.${
          pancard.name.split(".")[
            pancard.name.split(".").length - 1
          ]
        }`,
        Body: pancard.data,
      };
  
      const adharnoParams = {
        Bucket: s3Config.bucket,
        ACL : 'public-read',
        Key: `service/${req.body.email}-adharno-ser-${
          adharno.name.split(".")[
            adharno.name.split(".").length - 2
          ]
        }.${
          adharno.name.split(".")[
            adharno.name.split(".").length - 1
          ]
        }`,
        Body: adharno.data,
      };
  
      const passportPhotoParams = {
        Bucket: s3Config.bucket,
        ACL : 'public-read',
        Key: `service/${req.body.email}-passportPhoto-ser-${
          passportPhoto.name.split(".")[
            passportPhoto.name.split(".").length - 2
          ]
        }.${
          passportPhoto.name.split(".")[
            passportPhoto.name.split(".").length - 1
          ]
        }`,
        Body: passportPhoto.data,
      };
  
      let filesUpload = []
  
      let pancardUpload = s3.upload(pancardParams).promise()
      let adharnoUpload = s3.upload(adharnoParams).promise()
      let passportPhotoUpload = s3.upload(passportPhotoParams).promise()
      filesUpload.push(pancardUpload)
      filesUpload.push(adharnoUpload)
      filesUpload.push(passportPhotoUpload)
  
      let resignationFormParams = null
      let payslipsParams1 = null
      let payslipsParams2 = null
      let payslipsParams3 = null
  
      if(resignationForm)
      {
        resignationFormParams = {
          Bucket: s3Config.bucket,
          ACL : 'public-read',
          Key: `service/${req.body.email}-resginform-ser-${
            resignationForm.name.split(".")[
              resignationForm.name.split(".").length - 2
            ]
          }.${
            resignationForm.name.split(".")[
              resignationForm.name.split(".").length - 1
            ]
          }`,
          Body: resignationForm.data,
        };
        filesUpload.push(s3.upload(resignationFormParams).promise())
      }
  
      if(payslipMonth1)
      {
        payslipsParams1 = {
          Bucket: s3Config.bucket,
          ACL : 'public-read',
          Key: `service/${req.body.email}-payslipMonth1-ser-${
            payslipMonth1.name.split(".")[
              payslipMonth1.name.split(".").length - 2
            ]
          }.${
            payslipMonth1.name.split(".")[
              payslipMonth1.name.split(".").length - 1
            ]
          }`,
          Body: payslipMonth1.data,
        };
  
        filesUpload.push(s3.upload(payslipsParams1).promise())
      }
      if(payslipMonth2)
      {
        payslipsParams2 = {
          Bucket: s3Config.bucket,
          ACL : 'public-read',
          Key: `service/${req.body.email}-payslipMonth2-ser-${
            payslipMonth2.name.split(".")[
              payslipMonth2.name.split(".").length - 2
            ]
          }.${
            payslipMonth2.name.split(".")[
              payslipMonth2.name.split(".").length - 1
            ]
          }`,
          Body: payslipMonth2.data,
        };
  
        filesUpload.push(s3.upload(payslipsParams2).promise())
      }
      if(payslipMonth3)
      {
        payslipsParams3 = {
          Bucket: s3Config.bucket,
          ACL : 'public-read',
          Key: `service/${req.body.email}-payslipMonth3-ser-${
            payslipMonth3.name.split(".")[
              payslipMonth3.name.split(".").length - 2
            ]
          }.${
            payslipMonth3.name.split(".")[
              payslipMonth3.name.split(".").length - 1
            ]
          }`,
          Body: payslipMonth3.data,
        };
  
        filesUpload.push(s3.upload(payslipsParams3).promise())
      }
  
      Promise.all(filesUpload).then(function(data){

        req.body.pancard = data.length >= 1 ? data[0] : null
        req.body.adharno = data.length >= 2  ? data[1] : null
        req.body.passportPhoto = data.length >= 3 ? data[2] : null
        req.body.resignationForm = data.length >= 4 ? data[3] : null
        req.body.payslipMonth1 = data.length >=5 ? data[4] : null
        req.body.payslipMonth2 = data.length >=6 ? data[5] : null
        req.body.payslipMonth3 = data.length >=7 ? data[6] : null

        console.log(data)
  
        pResolve(data)
        }).catch(function(err){
          throw err;
        }) 
  
    }).then((resolve) => {
      next();
    });
};

functions.paySlipUploadS3 = async (req , res , next) => {

  await new Promise((pResolve, pReject) => {
    const params = {
      Bucket: s3Config.bucket,
      ACL : 'public-read',
      Key: `service/${req.body.userId.toString()}-ser-${
        req.files.paySlip.name.split(".")[
          req.files.paySlip.name.split(".").length - 2
        ]
      }.${
        req.files.paySlip.name.split(".")[
          req.files.paySlip.name.split(".").length - 1
        ]
      }`,
      Body: req.files.paySlip.data,
    };

    // Uploading files to the bucket
    s3.upload(params, function (err, data) {
      if (err) {
        throw err;
      }
      console.log("data?.Location", data.Location);
      pResolve(data.Location);
    });
  }).then((resolve) => {
    req.paySlip = [];
    req.paySlip.push(resolve);
    next();
  });
  
}


functions.mediaDeleteS3 = function (filename, callback) {
  console.log(filename);
  var s3 = new AWS.S3();
  var params = {
    Bucket: s3Config.bucket,
    Key: filename,
  };

  s3.deleteObject(params, function (err, data) {
    if (data) {
      console.log("file deleted", data);
    } else {
      console.log("err in delete object", err);
      // callback(null);
    }
  });
};

module.exports = exports = functions;
