const enums = require("../../json/enums.json");
const messages = require("../../json/messages.json");

module.exports = (app, logger) => {
  // imports all route here

  const userRoute = require("../routes/user/index");
  const eventsRoute = require("../routes/event/index");
  const holidayRoute = require("../routes/holiday/index");
  const leaveRoute = require("../routes/leaves/index");
  const paySlipRoute = require("../routes/paySlips/index");
  const onboardingRoute = require("../routes/onboarding/index")
  const timesheetRoute = require("../routes/timesheet/index")
  const clientRoute = require("../routes/clients/index")
  const projectRoute = require("../routes/projects/index")

  // define all routes here
  const { createResponseObject } = require("../utils");

  app.use(["/api/v1/user"], userRoute);
  app.use(["/api/v1/event"], eventsRoute);
  app.use(["/api/v1/holiday"], holidayRoute);
  app.use(["/api/v1/leave"], leaveRoute);
  app.use(["/api/v1/pay-slip"], paySlipRoute);
  app.use(["/api/v1/onboarding"] , onboardingRoute )
  app.use(["/api/v1/timesheet"] , timesheetRoute)
  app.use(["/api/v1/client"] , clientRoute)
  app.use(["/api/v1/project"] , projectRoute)

  /* Catch all */
  app.all("*", function (req, res) {
    res.status(enums.HTTP_CODES.BAD_REQUEST).json(
      createResponseObject({
        req: req,
        result: -1,
        message: "Sorry! The request could not be processed!",
        payload: {},
        logPayload: false,
      })
    );
  });

  // Async error handler
  app.use((error, req, res) => {
    logger.error(
      `${req.originalUrl} - Error caught by error-handler (router.js): ${error.message}\n${error.stack}`
    );
    const data4responseObject = {
      req: req,
      result: -999,
      message: messages.GENERAL,
      payload: {},
      logPayload: false,
    };

    return res
      .status(enums.HTTP_CODES.INTERNAL_SERVER_ERROR)
      .json(createResponseObject(data4responseObject));
  });
};
