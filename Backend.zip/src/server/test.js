var pdf = require("pdf-creator-node");
var fs = require("fs");

const writeXlsxFile = require('write-excel-file/node')

// var options = {
//     format: "A2",
//     orientation: "landscape",
//     border: "10mm",
// };

// const schema = [
//     {
//       column: 'Date',
//       type: String,
//       value: item => item.date
//     },
//     {
//       column: 'Day',
//       width:10,
//       type: String,
//       value: item => item.day
//     },
//     {
//       column: 'Work Hrs',
//       type: Number,
//       width:10,
//       value: item => item.work_hrs
//     },
//     {
//         column: 'Away Hrs',
//         type: Number,
//         width:10,
//         value: item => item.away_hrs
//       },
//     {
//       column: 'Client',
//       width:20,
//       type: String,
//       value: item => item.clientName
//     },
//     {
//         column: 'Project',
//         type: String,
//         width:20,
//         value: item => item.projectName
//       },
//       {
//         column: 'Description',
//         type: String,
//         width:100,
//         value: item => item.description
//       },

//   ]
  
//   const DATA_ROW_1 = [
//     // "Name"
//     {
//       type: String,
//       value: 'John Smith'
//     },
  
//     // "Date of Birth"
//     {
//       type: Date,
//       value: new Date(),
//       format: 'mm/dd/yyyy'
//     },
  
//     // "Cost"
//     {
//       type: Number,
//       value: 1800
//     },
  
//     // "Paid"
//     {
//       type: Boolean,
//       value: true
//     }
//   ]
  
//   const data = [
//     HEADER_ROW,
//     DATA_ROW_1,
//   ];

// // Read HTML Template
// var html = fs.readFileSync(require('path').resolve(__dirname,"../../template/timesheet.html"), "utf8");
// console.log("Asdas");

// global.models.GLOBAL.TIMESHEET_FILL.findOne({_id:("637641a48193db4794dde22d")}).then(findOnboardingEmployee=>{
//     findOnboardingEmployee = JSON.parse(JSON.stringify(findOnboardingEmployee));
//     // const output = fs.createWriteStream('./file.xlsx');
//     //  writeXlsxFile(findOnboardingEmployee.timesheet, { 
//     //     schema,
//     //     stickyRowsCount: 1,
//     //     headerStyle: {
//     //         backgroundColor: '#eeeeee',
//     //         fontWeight: 'bold',
//     //         align: 'center'
//     //       },
//     //     // fileName: './file.xlsx'
//     //   }).then(e=>{
//     //     console.log(e);
//     //     e.pipe(output);
//     //   }).catch(e=>{
//     //     console.error(e);
//     //   })
// // console.log(findOnboardingEmployee);
// // var document = {
// //     html: html,
// //     data: {
// //       data: findOnboardingEmployee.timesheet,
// //     },
// //     path: "./output.pdf",
// //     type: "",
// //   };
// //   pdf
// //   .create(document, options)
// //   .then((res) => {
// //     console.log(res);
// //   })
// //   .catch((error) => {
// //     console.error(error);
// //   });
// });
