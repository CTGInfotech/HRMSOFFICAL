const express = require("express");
const {
  loadConfigurationFromFile,
  loadConfigurationFromDatabase,
} = require("./configuration-loader");
const initDataBase = require("./database");
const os = require("os");
const initMiddleware = require("./middlewares");
const initRouter = require("./router");
const http = require("http");
const startScheduler = require("../scheduler");

global.config = {};
global.limits = {};
global.models = {};
global.menuList = {};

const runServer = async () => {
  const app = express();
  require("../polyfills");
  /* Logger */
  const logger = require("../logger");
  logger.info("Logger Initialized!");

  await loadConfigurationFromFile(logger);

  // Init Database connection
  await initDataBase(logger);

  // Init firestore Database
  // await initFirestore(logger);

  logger.info(`
    APP_ENVIRONMENT: ${process.env.APP_ENVIRONMENT}
    APP_NAME: ${process.env.APP_NAME}
    PORT: ${process.env.PORT}
    APP_RELEASE: ${process.env.APP_RELEASE}
    APP_VERSION: ${process.env.APP_VERSION}`);

  initMiddleware(app, logger);
  initRouter(app, logger);

  // const server = https.createServer(
  //   {
  //     key: fs.readFileSync("server.key"),
  //     cert: fs.readFileSync("server.cert"),
  //   },
  //   app
  // );
  const server = http.createServer(app);

  server.listen(process.env.PORT, async () => {
    logger.info(
      `${process.env.APP_RELEASE} server STARTED on port: ${process.env.PORT}\n`
    );

    require("./test");

    //* Additional info
    // const msg = `\`${process.env.APP_ENVIRONMENT}\` \`${os.hostname()}\` \`${process.env.APP_RELEASE}\` server *STARTED* on port \`${process.env.PORT}\``;
    // logger.info(`${msg}`);
  });

  server.timeout = 120000;

  // process.setMaxListeners(30); // or set to Infinity
  process.on("SIGINT", () => {
    server.close(async () => {
      const convertToMB = (data) =>
        Math.round((data / 1024 / 1024) * 100) / 100;
      const formatMemoryUsage = (data) => `${convertToMB(data)} MB`;
      const memoryData = process.memoryUsage();
      const memoryUsage = {
        rss: `Total memory allocated: ${formatMemoryUsage(memoryData.rss)}, `,
        heapTotal: `Total heap size: ${formatMemoryUsage(
          memoryData.heapTotal
        )}, `,
        heapUsed: `Actual memory used during the execution: ${formatMemoryUsage(
          memoryData.heapUsed
        )}, `,
        external: `V8 external memory: ${formatMemoryUsage(
          memoryData.external
        )}`,
      };
      const usageInPercent = Number(
        (convertToMB(memoryData.heapUsed) * 100) /
          convertToMB(memoryData.heapTotal)
      ).toFixed(2);
      const usageText = `${memoryUsage.rss}\n${memoryUsage.heapTotal}\n${memoryUsage.heapUsed}\n${memoryUsage.external}\nHeap usage is: ${usageInPercent}%`;
      const msg = `\`${process.env.APP_ENVIRONMENT}\` \`${
        process.env.APP_RELEASE
      }\` \`${os.hostname()}\` server *STOPPED* on *SIGINT*\`\`\`${usageText}\`\`\``;
      logger.error(msg.replace(/\//g, "").replace(/`/g, ""));
    });
  });
  process.on("SIGTERM", () => {
    server.close(async () => {
      const convertToMb = (data) =>
        Math.round((data / 1024 / 1024) * 100) / 100;
      const formatMemoryUsage = (data) => `${convertToMb(data)} MB`;
      const memoryData = process.memoryUsage();
      const memoryUsage = {
        rss: `Total memory allocated: ${formatMemoryUsage(memoryData.rss)}, `,
        heapTotal: `Total heap size: ${formatMemoryUsage(
          memoryData.heapTotal
        )}, `,
        heapUsed: `Actual memory used during the execution: ${formatMemoryUsage(
          memoryData.heapUsed
        )}, `,
        external: `V8 external memory: ${formatMemoryUsage(
          memoryData.external
        )}`,
      };
      const usageInPercent = Number(
        (convertToMb(memoryData.heapUsed) * 100) /
          convertToMb(memoryData.heapTotal)
      ).toFixed(2);
      const usageText = `${memoryUsage.rss}\n${memoryUsage.heapTotal}\n${memoryUsage.heapUsed}\n${memoryUsage.external}\nHeap usage is: ${usageInPercent}%`;
      const msg = `\`${process.env.APP_ENVIRONMENT}\` \`${
        process.env.APP_RELEASE
      }\` \`${os.hostname()}\` server *STOPPED* on *SIGINT*\`\`\`${usageText}\`\`\``;
      logger.error(msg.replace(/\//g, "").replace(/`/g, ""));
    });
  });

   startScheduler();
};

module.exports = runServer;
