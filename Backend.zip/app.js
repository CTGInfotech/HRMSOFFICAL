require("dotenv").config();
const runServer = require("./src/server");

runServer();
